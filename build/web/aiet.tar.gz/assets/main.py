# /// script
# dependencies = [
#   "numpy",
# ]
# ///
"""
Browser entry point for pygbag (Python + Pygame → WASM).

Local desktop run (unchanged): python src/main.py
Browser packaging: pip install pygbag && python -m pygbag --build --app_name aiet .
See docs/WEB_DEPLOY.md.
"""
from __future__ import annotations

import asyncio
import os
import sys

_root = os.path.dirname(os.path.abspath(__file__))
if _root not in sys.path:
    sys.path.insert(0, _root)

from src.main import main

asyncio.run(main())
