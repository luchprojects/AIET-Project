"""
SimulationEngine: dual-mode physics for AIET.

Mode A (Keplerian): single-star systems — O(1) parametric orbits, high-speed.
Mode B (N-Body): multi-star/binary systems — Symplectic Leapfrog, barycentric.
All physics in consistent units: AU, year, M_sun (G explicit).
G_AU = 39.478 AU^3 / (M_sun * year^2).
"""
import math
import numpy as np
from dataclasses import dataclass
from typing import Dict, List, Optional, Any, Tuple

# SI-derived gravitational constant in AU^3 / (M_sun * year^2)
# G_SI = 6.67430e-11 m^3/(kg*s^2); 1 AU = 1.495978707e11 m; 1 yr = 3.15576e7 s; M_sun = 1.9885e30 kg
G_AU = 39.478  # AU^3 / (M_sun * year^2)
# Planets: M_sun = M_earth * 3.003e-6 (task-specified conversion)
M_EARTH_TO_SOLAR_FACTOR = 3.003e-6  # M_earth -> M_sun
M_EARTH_TO_M_SUN = 1.0 / M_EARTH_TO_SOLAR_FACTOR  # ~333030, for legacy

# Radii in AU for collision/softening (1 R_earth ~ 4.26e-5 AU)
R_EARTH_AU = 4.26e-5   # 1 R_earth in AU
R_SUN_AU = 0.00465047  # 1 R_sun in AU (solar radius in AU)

# Runaway greenhouse flux threshold (Earth flux units) for thermal instability flag
RUNAWAY_FLUX_THRESHOLD = 1.2

# Flux integration: number of samples over one orbital period
N_FLUX_SAMPLES = 32


@dataclass
class CelestialBody:
    name: str
    mass: float  # in Earth masses
    radius: float  # in Earth radii
    position: np.ndarray  # in AU
    velocity: np.ndarray  # in AU/year
    temperature: float  # in Kelvin
    atmosphere: Dict[str, float]  # composition by mass fraction
    type: str  # 'star', 'planet', etc.
    orbper: float = 365.25  # orbital period in days
    orbeccen: float = 0.0  # orbital eccentricity
    
    def __post_init__(self):
        self.acceleration = np.zeros(3)
        self.habitability_score = 0.0
        # For stellar parameters if it's a star
        self.lum = 1.0  # in Solar luminosities
        if self.type == 'star':
            # Stefan-Boltzmann calculation for luminosity if not provided
            # st_lum = (st_rad^2) * (st_teff / 5778.0)^4
            # radius is in Earth radii, convert to solar radii: 1 solar radius = 109.2 Earth radii
            solar_rad = self.radius / 109.2
            self.lum = (solar_rad**2) * (self.temperature / 5778.0)**4

class SimulationEngine:
    def __init__(self):
        self.bodies: List[CelestialBody] = []
        self.G = G_AU  # Gravitational constant AU^3/(M_sun * year^2)
        self.time_step = 0.01  # in years
        self._nbody_substeps = 20  # sub-steps per UI frame for N-body stability
        self._last_energy_drift: Optional[float] = None  # for Numerical Stability indicator
        self._nbody_energy_initial: Optional[float] = None  # E0 at mode switch (for drift telemetry)
        self.ml_calculator = None  # Habitability via UI/ml_habitability only
        
    def add_body(self, body: CelestialBody):
        self.bodies.append(body)
        
    def find_host_star(self, body: CelestialBody) -> Optional[CelestialBody]:
        """Find the most massive star that this body might be orbiting"""
        stars = [b for b in self.bodies if b.type == 'star']
        if not stars:
            return None
        # Return the most massive star for now
        return max(stars, key=lambda s: s.mass)

    def calculate_acceleration(self, body: CelestialBody) -> np.ndarray:
        """Calculate gravitational acceleration on a body due to all other bodies"""
        acceleration = np.zeros(3)
        for other in self.bodies:
            if other != body:
                # Convert mass from Earth masses to Solar masses for the calculation
                # if the other body is a star, mass might already be in solar masses?
                # Looking at main.py, sun mass is 1.0 (Solar mass), planets are in Earth masses.
                # This is inconsistent. Let's assume stars are in Solar masses and planets in Earth masses.
                # M_sun = 333,030 M_earth
                other_mass_solar = other.mass if other.type == 'star' else other.mass / 333030.0
                
                r = other.position - body.position
                r_mag = np.linalg.norm(r)
                if r_mag > 1e-5:  # Avoid division by zero and near-collisions
                    acceleration += self.G * other_mass_solar * r / (r_mag ** 3)
        return acceleration
    
    def update_positions(self):
        """Update positions and velocities using Verlet integration"""
        for body in self.bodies:
            body.acceleration = self.calculate_acceleration(body)
            body.velocity += body.acceleration * self.time_step
            body.position += body.velocity * self.time_step
            
    def calculate_habitability(self, body: CelestialBody) -> float:
        """Calculate habitability score using ML model if available, otherwise use basic physics"""
        if body.type != 'planet':
            return 0.0

        star = self.find_host_star(body)
        if not star:
            return 0.0

        # Calculate distance to star for insolation
        distance = np.linalg.norm(body.position - star.position)
        if distance < 1e-5:
            distance = 1.0 # default to 1 AU
            
        # pl_insol = st_lum / (distance^2)
        pl_insol = star.lum / (distance**2)

        if self.ml_calculator:
            features = {
                "pl_rade": body.radius,
                "pl_masse": body.mass,
                "pl_orbper": body.orbper,
                "pl_orbeccen": body.orbeccen,
                "pl_insol": pl_insol,
                "st_teff": star.temperature,
                "st_mass": star.mass,
                "st_rad": star.radius / 109.2, # Convert Earth radii back to Solar radii for ML
                "st_lum": star.lum
            }
            # The ML model returns percentage (0-100)
            return self.ml_calculator.predict(features)
        
        # Fallback to basic calculation if ML is not available
        score = 0.0
        # ... (rest of old logic)
        temp_factor = 1.0 - abs(body.temperature - 288) / 100
        score += max(0, temp_factor) * 0.3
        mass_factor = 1.0 - abs(body.mass - 1.0) / 2.0
        score += max(0, mass_factor) * 0.3
        if 'O2' in body.atmosphere and body.atmosphere['O2'] > 0.1:
            score += 0.2
        if 'H2O' in body.atmosphere and body.atmosphere['H2O'] > 0:
            score += 0.2
        return min(1.0, score) * 100.0 # Convert to percentage to match ML output
    
    def step(self, dt: float = 0.01):
        """Advance the simulation by one time step (legacy CelestialBody list)."""
        self.update_positions()
        for body in self.bodies:
            if body.type == 'planet':
                body.habitability_score = self.calculate_habitability(body)

    # ---------- Dual-mode architecture ----------

    @staticmethod
    def physics_mode(placed_bodies: List[Dict[str, Any]]) -> str:
        """
        Determine integration mode from placed bodies.
        Mode A: len(stars) == 1 -> Keplerian (analytic).
        Mode B: len(stars) > 1 -> N-body (Leapfrog).
        """
        stars = [b for b in placed_bodies if b.get("type") == "star"]
        return "nbody" if len(stars) > 1 else "keplerian"

    @staticmethod
    def _mass_solar(b: Dict[str, Any]) -> float:
        """Return mass in Solar masses. Stars in M_sun; planets/moons: M_earth * 3.003e-6."""
        t = b.get("type", "planet")
        m = float(b.get("mass", 1.0))
        return m if t == "star" else m * M_EARTH_TO_SOLAR_FACTOR

    @staticmethod
    def _radius_au(b: Dict[str, Any]) -> float:
        """Return body radius in AU for collision/softening. Stars in R_sun, others in R_earth."""
        r = float(b.get("radius", b.get("actual_radius", 1.0)))
        return r * R_SUN_AU if b.get("type") == "star" else r * R_EARTH_AU

    def _initialize_nbody_state(
        self,
        body_dicts: List[Dict[str, Any]],
        scale_px_per_au: float,
    ) -> None:
        """
        Keplerian → N-body handover: set position_au and velocity_au for every body from
        current orbital elements, then barycentric correction so CoM is at (0,0) and
        total momentum is zero. Stores E0 in _nbody_energy_initial for drift telemetry.

        For planets/moons: velocity from vis-viva v = sqrt(G*M*(2/r - 1/a)), tangent
        direction (-sin θ, cos θ) at true anomaly θ. r = a(1-e²)/(1+e*cos θ).
        Uses G_AU = 39.478. All units AU, year, M_sun.
        """
        if not body_dicts or scale_px_per_au <= 0:
            return
        G = self.G
        N = len(body_dicts)
        positions_au = np.zeros((N, 2))
        velocities_au = np.zeros((N, 2))
        masses = np.zeros(N)
        # Masses for all (needed for parent mass in vis-viva)
        for i in range(N):
            masses[i] = self._mass_solar(body_dicts[i])
        # Process in dependency order: stars first, then planets, then moons (parent before child)
        type_order = {"star": 0, "planet": 1, "moon": 2}
        order = sorted(range(N), key=lambda i: type_order.get(body_dicts[i].get("type", "planet"), 1))

        # 1) Positions and velocities from Keplerian state
        for i in order:
            b = body_dicts[i]
            t = b.get("type", "planet")

            if t == "star":
                pos_px = b.get("position")
                if pos_px is not None and len(pos_px) >= 2:
                    positions_au[i] = np.array([float(pos_px[0]), float(pos_px[1])]) / scale_px_per_au
                # Use preset orbital velocity if provided (e.g. Alpha Cen binary); else zero
                vel = b.get("velocity_au")
                if vel is not None and hasattr(vel, "__len__") and len(vel) >= 2:
                    velocities_au[i] = np.array([float(vel[0]), float(vel[1])], dtype=float)
                else:
                    velocities_au[i] = 0.0
                continue

            # Planet or moon: orbital elements relative to parent
            parent = b.get("parent_obj")
            a_au = float(b.get("semiMajorAxis", 1.0))
            e = float(b.get("eccentricity", 0.0))
            e_safe = min(max(e, 0.0), 0.999)
            theta = float(b.get("orbit_angle", 0.0))

            if parent is None or a_au <= 0:
                pos_px = b.get("position")
                if pos_px is not None and len(pos_px) >= 2:
                    positions_au[i] = np.array([float(pos_px[0]), float(pos_px[1])]) / scale_px_per_au
                velocities_au[i] = 0.0
                continue

            # Parent index and mass (for vis-viva)
            try:
                j = body_dicts.index(parent)
            except ValueError:
                j = None
            if j is None:
                pos_px = b.get("position")
                if pos_px is not None and len(pos_px) >= 2:
                    positions_au[i] = np.array([float(pos_px[0]), float(pos_px[1])]) / scale_px_per_au
                velocities_au[i] = 0.0
                continue

            M_parent = masses[j]
            parent_pos = positions_au[j]

            # r = a(1-e²)/(1+e*cos(θ))
            r_au = a_au * (1.0 - e_safe * e_safe) / (1.0 + e_safe * math.cos(theta))
            r_au = max(r_au, 1e-10)
            # Position relative to parent: r*(cos θ, sin θ)
            rx = r_au * math.cos(theta)
            ry = r_au * math.sin(theta)
            positions_au[i] = parent_pos + np.array([rx, ry])

            # Vis-viva: v = sqrt(G*M*(2/r - 1/a)); tangent direction (-sin θ, cos θ)
            v_mag_sq = G * M_parent * (2.0 / r_au - 1.0 / a_au)
            v_mag = math.sqrt(max(0.0, v_mag_sq))
            tx = -math.sin(theta)
            ty = math.cos(theta)
            velocities_au[i] = np.array([v_mag * tx, v_mag * ty])

        # 2) Barycentric correction: shift so CoM at (0,0)
        total_mass = float(np.sum(masses))
        if total_mass > 1e-30:
            com = np.zeros(2)
            for i in range(N):
                com += masses[i] * positions_au[i]
            com /= total_mass
            positions_au -= com

        # 3) Zero total momentum: v_com = sum(m*v)/sum(m), then v -= v_com
        if total_mass > 1e-30:
            p_total = np.zeros(2)
            for i in range(N):
                p_total += masses[i] * velocities_au[i]
            v_com = p_total / total_mass
            velocities_au -= v_com

        # 4) Write back into body dicts
        for i, b in enumerate(body_dicts):
            if b.get("is_destroyed", False):
                continue
            b["position_au"] = positions_au[i].copy()
            b["velocity_au"] = velocities_au[i].copy()
            b["position"] = positions_au[i] * scale_px_per_au

        # 5) Store E0 at switch for telemetry (_last_energy_drift = |(E - E0)/E0|)
        try:
            self._nbody_energy_initial = self._total_energy_nbody(
                positions_au, velocities_au, masses, body_dicts
            )
        except Exception:
            self._nbody_energy_initial = None

    def _calculate_accelerations(
        self,
        positions_au: np.ndarray,
        masses_solar: np.ndarray,
        body_dicts: Optional[List[Dict[str, Any]]] = None,
        radii_au: Optional[np.ndarray] = None,
    ) -> np.ndarray:
        """
        For every body i: a_i = sum_{j != i} (G_AU * M_j / |r_ij|^3) * r_ij, r_ij = r_j - r_i.
        Uses G_AU = 39.478 (AU^3 / M_sun * year^2). Masses in M_sun.
        Collision safety: if |r_ij| < (R_i + R_j), set is_destroyed=True on both and skip that pair.
        Returns (N, 2) accelerations in AU/year^2.
        """
        N = positions_au.shape[0]
        acc = np.zeros((N, 2))
        use_collision = body_dicts is not None and radii_au is not None
        for i in range(N):
            if use_collision and body_dicts[i].get("is_destroyed", False):
                continue
            r_i = positions_au[i]
            for j in range(N):
                if j == i:
                    continue
                if use_collision and body_dicts[j].get("is_destroyed", False):
                    continue
                r_ij = positions_au[j] - r_i
                r_mag = np.linalg.norm(r_ij)
                if use_collision and radii_au is not None:
                    r_sum = radii_au[i] + radii_au[j]
                    if r_mag < r_sum:
                        body_dicts[i]["is_destroyed"] = True
                        body_dicts[j]["is_destroyed"] = True
                        continue
                if r_mag < 1e-10:
                    continue
                acc[i] += G_AU * masses_solar[j] * r_ij / (r_mag ** 3)
        return acc

    def _barycentric_acceleration(
        self, i: int, positions_au: np.ndarray, masses_solar: np.ndarray
    ) -> np.ndarray:
        """
        a_i = sum_{j != i} G * m_j * r_ij / |r_ij|^3, r_ij = r_j - r_i.
        No collision check (used from flux sampling where no body_dicts). Softening only.
        """
        r_i = positions_au[i]
        a = np.zeros(2)
        for j in range(len(positions_au)):
            if j == i:
                continue
            r_ij = positions_au[j] - r_i
            r_mag = np.linalg.norm(r_ij)
            if r_mag < 1e-10:
                continue
            a += self.G * masses_solar[j] * r_ij / (r_mag ** 3)
        return a

    def step_nbody(
        self,
        dt_years: float,
        body_dicts: List[Dict[str, Any]],
        n_sub: Optional[int] = None,
        scale_px_per_au: float = 400.0,
    ) -> Optional[float]:
        """
        Advance N-body system by dt_years using Symplectic Leapfrog (Velocity Verlet).
        Updates position_au and velocity_au in each body dict at every sub-step.
        Optionally returns relative energy drift |dE/E0| for stability indicator.

        Body dicts must have: type, mass, position_au (2D), velocity_au (2D).
        Stars: mass in M_sun; planets/moons: mass in M_earth.
        After return, caller should set position (px) = position_au * scale_px_per_au.
        """
        if not body_dicts or dt_years <= 0:
            return None
        n_sub = n_sub if n_sub is not None else self._nbody_substeps
        dt_sub = dt_years / n_sub

        N = len(body_dicts)
        positions = np.zeros((N, 2))
        velocities = np.zeros((N, 2))
        masses = np.zeros(N)
        radii_au = np.zeros(N)
        for i, b in enumerate(body_dicts):
            pos = b.get("position_au")
            vel = b.get("velocity_au")
            if pos is not None and vel is not None:
                positions[i] = np.asarray(pos, dtype=float).reshape(2)
                velocities[i] = np.asarray(vel, dtype=float).reshape(2)
            masses[i] = self._mass_solar(b)
            radii_au[i] = self._radius_au(b)

        for _ in range(n_sub):
            # Destroyed bodies: no motion (avoid 1/r^3 blow-up; UI ignores them)
            for i, b in enumerate(body_dicts):
                if i < N and b.get("is_destroyed", False):
                    velocities[i][:] = 0.0
            # Velocity Verlet (Leapfrog):
            # Kick: v_half = v0 + a0 * dt/2
            acc = self._calculate_accelerations(positions, masses, body_dicts, radii_au)
            velocities += acc * (dt_sub * 0.5)
            # Drift: r1 = r0 + v_half * dt
            positions += velocities * dt_sub
            # Update accel: a1 = calculate_accelerations(new positions)
            acc = self._calculate_accelerations(positions, masses, body_dicts, radii_au)
            # Kick: v1 = v_half + a1 * dt/2
            velocities += acc * (dt_sub * 0.5)

            # Write back to body dicts at each sub-step; position_au -> screen_px via scale
            for i, b in enumerate(body_dicts):
                if b.get("is_destroyed", False):
                    continue
                b["position_au"] = positions[i].copy()
                b["velocity_au"] = velocities[i].copy()
                b["position"] = positions[i] * scale_px_per_au

        # Numerical stability: E0 from mode switch; expose |(E - E0) / E0| for ScientificDiagnosticsPanel
        drift = None
        e0 = self._nbody_energy_initial
        if e0 is not None and abs(e0) > 1e-30:
            try:
                e1 = self._total_energy_nbody(positions, velocities, masses, body_dicts)
                self._last_energy_drift = abs((e1 - e0) / e0)
                drift = self._last_energy_drift
            except Exception:
                pass
        return drift

    def _total_energy_nbody(
        self,
        positions: np.ndarray,
        velocities: np.ndarray,
        masses: np.ndarray,
        body_dicts: Optional[List[Dict[str, Any]]] = None,
    ) -> float:
        """
        Hamiltonian: E = sum_i (1/2 m_i v_i^2) - sum_{i<j} (G m_i m_j / r_ij).
        Units: AU, year, M_sun. Excludes destroyed bodies if body_dicts provided.
        """
        N = positions.shape[0]
        destroyed = set()
        if body_dicts is not None:
            destroyed = {i for i in range(N) if i < len(body_dicts) and body_dicts[i].get("is_destroyed", False)}
        ke = 0.0
        for i in range(N):
            if i in destroyed:
                continue
            ke += 0.5 * masses[i] * (np.sum(velocities[i] ** 2))
        pe = 0.0
        for i in range(N):
            if i in destroyed:
                continue
            for j in range(i + 1, N):
                if j in destroyed:
                    continue
                r = np.linalg.norm(positions[j] - positions[i])
                if r > 1e-10:
                    pe -= G_AU * masses[i] * masses[j] / r
        return ke + pe

    def compute_nbody_flux_metrics(
        self,
        body_dicts: List[Dict[str, Any]],
        planet_body: Dict[str, Any],
        period_years: float,
        n_samples: int = N_FLUX_SAMPLES,
    ) -> Tuple[float, float, bool]:
        """
        Stochastic flux integration over one orbital period T.
        Sample planet P at 32 intervals; at each t_k: S_total(t_k) = sum_stars L_star_n / d_pn(t_k)^2.
        S_avg = (1/32) * sum_k S_total(t_k), S_max = max_k S_total(t_k).
        thermal_instability = True if S_max > 1.2 (runaway greenhouse limit).
        Units: L in L_sun, d in AU -> flux in Earth flux units.
        """
        stars = [b for b in body_dicts if b.get("type") == "star"]
        if not stars or period_years <= 0:
            return 0.0, 0.0, False

        N = len(body_dicts)
        positions = np.zeros((N, 2))
        velocities = np.zeros((N, 2))
        masses = np.zeros(N)
        planet_idx = None
        for i, b in enumerate(body_dicts):
            if b is planet_body:
                planet_idx = i
            pos = b.get("position_au")
            vel = b.get("velocity_au")
            if pos is not None and vel is not None:
                positions[i] = np.asarray(pos, dtype=float).reshape(2)
                velocities[i] = np.asarray(vel, dtype=float).reshape(2)
            masses[i] = self._mass_solar(b)
        if planet_idx is None:
            return 0.0, 0.0, False

        dt_sample = period_years / n_samples
        flux_sum = 0.0
        s_max = 0.0
        for _ in range(n_samples):
            # S_total(t_k) = sum over stars: L_n / d_pn(t_k)^2
            s_total = 0.0
            r_planet = positions[planet_idx]
            for s in stars:
                j = body_dicts.index(s)
                d_pn = np.linalg.norm(positions[j] - r_planet)
                if d_pn < 1e-10:
                    d_pn = 1e-10
                L_n = float(s.get("luminosity", 1.0))
                s_total += L_n / (d_pn ** 2)
            flux_sum += s_total
            s_max = max(s_max, s_total)
            # Advance state by dt_sample (one Leapfrog step per sample; no collision check)
            acc = np.zeros((N, 2))
            for i in range(N):
                acc[i] = self._barycentric_acceleration(i, positions, masses)
            velocities += acc * (dt_sample * 0.5)
            positions += velocities * dt_sample
            for i in range(N):
                acc[i] = self._barycentric_acceleration(i, positions, masses)
            velocities += acc * (dt_sample * 0.5)

        s_avg = flux_sum / n_samples
        thermal_instability = s_max > RUNAWAY_FLUX_THRESHOLD
        return s_avg, s_max, thermal_instability
