"""
AIET Orbital Integrator Validation and Energy Conservation Diagnostics

Provides quantitative metrics to assess integrator stability and conservation
of energy and angular momentum over time. This module adds DIAGNOSTICS ONLY
and does not modify integration behavior.

Physics Background:
    - Total Energy E = K + U should be conserved in isolated N-body systems
    - Kinetic Energy: K = Σ (1/2) m_i v_i²
    - Potential Energy: U = -Σ_{i<j} G m_i m_j / r_ij
    - Angular Momentum: L = Σ m_i (r_i × v_i) should be conserved

Expected Drift Thresholds by Integrator Type:
    - Symplectic (Leapfrog/Verlet): Energy oscillates but should NOT drift.
      Typical |ΔE/E₀| < 1e-6 for short integrations, may grow slowly as O(dt²).
    - RK4: Small long-term drift expected. |ΔE/E₀| grows as O(dt⁴) per step,
      accumulates over time. Typical |ΔE/E₀| ~ 1e-8 to 1e-4 depending on dt.
    - Keplerian (kinematic): Energy is implicitly conserved by construction
      for two-body problems. Multi-body perturbations may introduce drift.

Usage:
    from integrator_diagnostics import IntegratorDiagnostics

    diag = IntegratorDiagnostics(G=39.478)  # G in AU³/(M_sun·year²)
    
    # During simulation loop:
    diag.record_state(bodies, timestep_index)
    
    # After simulation:
    metrics = diag.compute_drift_metrics()
    diag.export_energy_drift_plot("exports/energy_drift.png")
"""

from __future__ import annotations

import numpy as np
from typing import Dict, List, Tuple, Any, Optional
from dataclasses import dataclass, field


@dataclass
class BodyState:
    """Snapshot of a body's state at a given timestep."""
    name: str
    mass: float          # in consistent units (e.g., solar masses)
    position: np.ndarray # 2D or 3D position vector
    velocity: np.ndarray # 2D or 3D velocity vector


@dataclass
class DiagnosticsRecord:
    """Record of conserved quantities at a timestep."""
    timestep: int
    time: float
    total_energy: float
    kinetic_energy: float
    potential_energy: float
    angular_momentum_magnitude: float
    angular_momentum_vector: np.ndarray


@dataclass
class DriftMetrics:
    """Summary of conservation drift over simulation."""
    initial_energy: float
    final_energy: float
    max_energy_drift: float          # max |ΔE/E₀|
    final_energy_drift: float        # final |ΔE/E₀|
    mean_energy_drift: float         # mean |ΔE/E₀|
    
    initial_angular_momentum: float
    final_angular_momentum: float
    max_angular_momentum_drift: float   # max |ΔL/L₀|
    final_angular_momentum_drift: float # final |ΔL/L₀|
    
    total_timesteps: int
    total_simulation_time: float
    
    energy_history: List[float] = field(default_factory=list)
    angular_momentum_history: List[float] = field(default_factory=list)
    timestep_history: List[int] = field(default_factory=list)
    time_history: List[float] = field(default_factory=list)


class IntegratorDiagnostics:
    """
    Compute and track energy and angular momentum conservation diagnostics.
    
    This class is designed to be non-invasive: it observes simulation state
    and computes diagnostics without modifying integration behavior.
    
    Args:
        G: Gravitational constant in simulation units.
           Default: 39.478 AU³/(M_sun·year²) for solar system simulations.
        record_interval: Record diagnostics every N timesteps (default 1).
    """
    
    # Unit conversion for common mass representations
    EARTH_MASS_TO_SOLAR = 1.0 / 333030.0
    
    def __init__(
        self,
        G: float = 39.478,
        record_interval: int = 1,
    ):
        self.G = G
        self.record_interval = max(1, record_interval)
        self.records: List[DiagnosticsRecord] = []
        self._current_timestep = 0
        self._current_time = 0.0
    
    def reset(self):
        """Clear all recorded diagnostics."""
        self.records.clear()
        self._current_timestep = 0
        self._current_time = 0.0
    
    def compute_kinetic_energy(self, bodies: List[BodyState]) -> float:
        """
        Compute total kinetic energy: K = Σ (1/2) m_i v_i²
        
        Args:
            bodies: List of body states with mass and velocity.
            
        Returns:
            Total kinetic energy in simulation units.
        """
        K = 0.0
        for body in bodies:
            v_squared = np.dot(body.velocity, body.velocity)
            K += 0.5 * body.mass * v_squared
        return K
    
    def compute_potential_energy(self, bodies: List[BodyState]) -> float:
        """
        Compute total gravitational potential energy: U = -Σ_{i<j} G m_i m_j / r_ij
        
        Args:
            bodies: List of body states with mass and position.
            
        Returns:
            Total potential energy (negative) in simulation units.
        """
        U = 0.0
        n = len(bodies)
        for i in range(n):
            for j in range(i + 1, n):
                r_vec = bodies[j].position - bodies[i].position
                r_mag = np.linalg.norm(r_vec)
                if r_mag > 1e-10:
                    U -= self.G * bodies[i].mass * bodies[j].mass / r_mag
        return U
    
    def compute_total_energy(self, bodies: List[BodyState]) -> Tuple[float, float, float]:
        """
        Compute total mechanical energy E = K + U.
        
        Args:
            bodies: List of body states.
            
        Returns:
            Tuple of (total_energy, kinetic_energy, potential_energy).
        """
        K = self.compute_kinetic_energy(bodies)
        U = self.compute_potential_energy(bodies)
        return (K + U, K, U)
    
    def compute_angular_momentum(self, bodies: List[BodyState]) -> Tuple[float, np.ndarray]:
        """
        Compute total angular momentum: L = Σ m_i (r_i × v_i)
        
        For 2D simulations, cross product gives scalar (z-component).
        For 3D simulations, returns full vector magnitude.
        
        Args:
            bodies: List of body states with mass, position, velocity.
            
        Returns:
            Tuple of (magnitude, vector). For 2D, vector has shape (1,) or (3,).
        """
        L_total = np.zeros(3)
        
        for body in bodies:
            r = body.position
            v = body.velocity
            m = body.mass
            
            if len(r) == 2:
                r_3d = np.array([r[0], r[1], 0.0])
                v_3d = np.array([v[0], v[1], 0.0])
            else:
                r_3d = r if len(r) == 3 else np.append(r, [0.0] * (3 - len(r)))
                v_3d = v if len(v) == 3 else np.append(v, [0.0] * (3 - len(v)))
            
            L_total += m * np.cross(r_3d, v_3d)
        
        return (float(np.linalg.norm(L_total)), L_total)
    
    def record_state(
        self,
        bodies: List[BodyState],
        timestep: Optional[int] = None,
        time: Optional[float] = None,
    ):
        """
        Record diagnostics for current simulation state.
        
        Args:
            bodies: List of BodyState objects representing current state.
            timestep: Current timestep index (auto-incremented if None).
            time: Current simulation time (auto-tracked if None).
        """
        if timestep is None:
            timestep = self._current_timestep
        if time is None:
            time = self._current_time
            
        if timestep % self.record_interval != 0 and timestep != 0:
            self._current_timestep = timestep + 1
            return
        
        E_total, K, U = self.compute_total_energy(bodies)
        L_mag, L_vec = self.compute_angular_momentum(bodies)
        
        record = DiagnosticsRecord(
            timestep=timestep,
            time=time,
            total_energy=E_total,
            kinetic_energy=K,
            potential_energy=U,
            angular_momentum_magnitude=L_mag,
            angular_momentum_vector=L_vec.copy(),
        )
        self.records.append(record)
        self._current_timestep = timestep + 1
    
    def record_state_from_dicts(
        self,
        bodies: List[Dict[str, Any]],
        timestep: Optional[int] = None,
        time: Optional[float] = None,
        mass_key: str = "mass",
        position_key: str = "position",
        velocity_key: str = "velocity",
        body_type_key: str = "type",
        mass_in_earth_masses: bool = False,
        star_mass_in_solar: bool = True,
    ):
        """
        Record diagnostics from dict-based body representations (e.g., visualization.py bodies).
        
        Args:
            bodies: List of body dicts.
            timestep: Current timestep index.
            time: Current simulation time.
            mass_key: Key for mass in body dict.
            position_key: Key for position array in body dict.
            velocity_key: Key for velocity array in body dict.
            body_type_key: Key for body type (star/planet/moon).
            mass_in_earth_masses: If True, convert planet/moon masses to solar masses.
            star_mass_in_solar: If True, assume star masses are already in solar masses.
        """
        body_states = []
        
        for body in bodies:
            mass = body.get(mass_key, 0.0)
            position = body.get(position_key)
            velocity = body.get(velocity_key)
            body_type = body.get(body_type_key, "planet")
            
            if position is None or velocity is None:
                continue
            if mass <= 0:
                continue
                
            position = np.asarray(position, dtype=np.float64)
            velocity = np.asarray(velocity, dtype=np.float64)
            
            if mass_in_earth_masses and body_type != "star":
                mass = mass * self.EARTH_MASS_TO_SOLAR
            elif body_type == "star" and not star_mass_in_solar:
                mass = mass * self.EARTH_MASS_TO_SOLAR
            
            body_states.append(BodyState(
                name=body.get("name", "unknown"),
                mass=float(mass),
                position=position,
                velocity=velocity,
            ))
        
        if body_states:
            self.record_state(body_states, timestep, time)
    
    def compute_drift_metrics(self) -> DriftMetrics:
        """
        Compute drift metrics from recorded diagnostics.
        
        Returns:
            DriftMetrics object with energy and angular momentum drift statistics.
            
        Raises:
            ValueError: If no records have been recorded.
        """
        if not self.records:
            raise ValueError("No diagnostics recorded. Call record_state() during simulation.")
        
        energies = [r.total_energy for r in self.records]
        ang_moms = [r.angular_momentum_magnitude for r in self.records]
        timesteps = [r.timestep for r in self.records]
        times = [r.time for r in self.records]
        
        E0 = energies[0]
        L0 = ang_moms[0]
        
        if abs(E0) > 1e-15:
            energy_drifts = [abs((E - E0) / E0) for E in energies]
        else:
            energy_drifts = [abs(E - E0) for E in energies]
        
        if abs(L0) > 1e-15:
            angular_momentum_drifts = [abs((L - L0) / L0) for L in ang_moms]
        else:
            angular_momentum_drifts = [abs(L - L0) for L in ang_moms]
        
        return DriftMetrics(
            initial_energy=E0,
            final_energy=energies[-1],
            max_energy_drift=max(energy_drifts),
            final_energy_drift=energy_drifts[-1],
            mean_energy_drift=float(np.mean(energy_drifts)),
            
            initial_angular_momentum=L0,
            final_angular_momentum=ang_moms[-1],
            max_angular_momentum_drift=max(angular_momentum_drifts),
            final_angular_momentum_drift=angular_momentum_drifts[-1],
            
            total_timesteps=len(self.records),
            total_simulation_time=times[-1] - times[0] if len(times) > 1 else 0.0,
            
            energy_history=energies,
            angular_momentum_history=ang_moms,
            timestep_history=timesteps,
            time_history=times,
        )
    
    def get_energy_drift_array(self) -> Tuple[np.ndarray, np.ndarray]:
        """
        Get arrays of timesteps and relative energy drift ΔE/E₀.
        
        Returns:
            Tuple of (timesteps array, drift array).
        """
        if not self.records:
            return (np.array([]), np.array([]))
        
        energies = np.array([r.total_energy for r in self.records])
        timesteps = np.array([r.timestep for r in self.records])
        
        E0 = energies[0]
        if abs(E0) > 1e-15:
            drift = (energies - E0) / E0
        else:
            drift = energies - E0
        
        return (timesteps, drift)


def export_energy_drift_plot(
    diagnostics: IntegratorDiagnostics,
    output_path: str,
    use_time_axis: bool = False,
    figsize: Tuple[float, float] = (8, 5),
    title: str = "Energy Conservation Drift",
    show_angular_momentum: bool = False,
) -> str:
    """
    Export publication-quality energy drift plot.
    
    Plots ΔE/E₀ vs timestep (or time). White background, 300 DPI.
    
    Args:
        diagnostics: IntegratorDiagnostics instance with recorded data.
        output_path: Path to save PNG file.
        use_time_axis: If True, use simulation time on X-axis instead of timestep.
        figsize: Figure dimensions (width, height) in inches.
        title: Plot title.
        show_angular_momentum: If True, also plot ΔL/L₀ on secondary axis.
        
    Returns:
        Path to saved figure.
    """
    try:
        import matplotlib
        matplotlib.use('Agg')
        import matplotlib.pyplot as plt
    except ImportError:
        raise ImportError("matplotlib is required for export_energy_drift_plot()")
    
    metrics = diagnostics.compute_drift_metrics()
    
    if use_time_axis:
        x_data = metrics.time_history
        x_label = "Simulation Time"
    else:
        x_data = metrics.timestep_history
        x_label = "Timestep"
    
    E0 = metrics.initial_energy
    if abs(E0) > 1e-15:
        energy_drift = [(E - E0) / E0 for E in metrics.energy_history]
    else:
        energy_drift = [E - E0 for E in metrics.energy_history]
    
    fig, ax1 = plt.subplots(figsize=figsize, facecolor='white')
    ax1.set_facecolor('white')
    
    ax1.plot(x_data, energy_drift, 'b-', linewidth=1.2, label='ΔE/E₀')
    ax1.axhline(y=0, color='gray', linestyle='--', linewidth=0.8, alpha=0.5)
    
    ax1.set_xlabel(x_label, fontsize=11)
    ax1.set_ylabel('Relative Energy Drift (ΔE/E₀)', fontsize=11, color='blue')
    ax1.tick_params(axis='y', labelcolor='blue')
    
    if show_angular_momentum:
        ax2 = ax1.twinx()
        L0 = metrics.initial_angular_momentum
        if abs(L0) > 1e-15:
            L_drift = [(L - L0) / L0 for L in metrics.angular_momentum_history]
        else:
            L_drift = [L - L0 for L in metrics.angular_momentum_history]
        
        ax2.plot(x_data, L_drift, 'r-', linewidth=1.2, alpha=0.7, label='ΔL/L₀')
        ax2.set_ylabel('Relative Angular Momentum Drift (ΔL/L₀)', fontsize=11, color='red')
        ax2.tick_params(axis='y', labelcolor='red')
        
        lines1, labels1 = ax1.get_legend_handles_labels()
        lines2, labels2 = ax2.get_legend_handles_labels()
        ax1.legend(lines1 + lines2, labels1 + labels2, loc='best', fontsize=9)
    else:
        ax1.legend(loc='best', fontsize=9)
    
    ax1.set_title(title, fontsize=12, fontweight='bold')
    ax1.grid(True, alpha=0.3, linestyle='-', linewidth=0.5)
    
    for spine in ax1.spines.values():
        spine.set_linewidth(0.8)
    
    info_text = (f"Max |ΔE/E₀|: {metrics.max_energy_drift:.2e}\n"
                 f"Final |ΔE/E₀|: {metrics.final_energy_drift:.2e}")
    ax1.text(0.98, 0.98, info_text, transform=ax1.transAxes,
             fontsize=8, ha='right', va='top', color='gray',
             bbox=dict(boxstyle='round', facecolor='white', alpha=0.8))
    
    plt.tight_layout()
    fig.savefig(output_path, dpi=300, facecolor='white', edgecolor='none',
                bbox_inches='tight', pad_inches=0.1)
    plt.close(fig)
    
    print(f"[Integrator Diagnostics] Exported energy drift plot to: {output_path}")
    return output_path


def run_integrator_validation(
    bodies: List[Dict[str, Any]],
    duration: float,
    dt: float,
    G: float = 39.478,
    integrator: str = "verlet",
    record_interval: int = 10,
) -> DriftMetrics:
    """
    Run standalone integrator validation without UI overhead.
    
    Simulates the system for specified duration and returns drift metrics.
    
    Args:
        bodies: List of body dicts with mass, position, velocity, type.
        duration: Total simulation duration in simulation time units (e.g., years).
        dt: Time step size.
        G: Gravitational constant in simulation units.
        integrator: Integration method ("verlet" or "rk4").
        record_interval: Record diagnostics every N steps.
        
    Returns:
        DriftMetrics object with conservation statistics.
        
    Note:
        This function creates a deep copy of bodies and does not modify the originals.
    """
    import copy
    
    bodies_copy = copy.deepcopy(bodies)
    
    for body in bodies_copy:
        if "position" in body:
            body["position"] = np.asarray(body["position"], dtype=np.float64)
        if "velocity" in body:
            body["velocity"] = np.asarray(body["velocity"], dtype=np.float64)
    
    diag = IntegratorDiagnostics(G=G, record_interval=record_interval)
    
    n_steps = int(duration / dt)
    current_time = 0.0
    
    EARTH_MASS_TO_SOLAR = 1.0 / 333030.0
    
    def get_masses_solar(bodies_list):
        masses = []
        for b in bodies_list:
            m = b.get("mass", 0.0)
            if b.get("type") == "star":
                masses.append(m)
            else:
                masses.append(m * EARTH_MASS_TO_SOLAR)
        return masses
    
    def compute_accelerations(bodies_list, masses_solar):
        n = len(bodies_list)
        accels = [np.zeros_like(bodies_list[0]["position"]) for _ in range(n)]
        
        for i in range(n):
            for j in range(n):
                if i != j:
                    r_vec = bodies_list[j]["position"] - bodies_list[i]["position"]
                    r_mag = np.linalg.norm(r_vec)
                    if r_mag > 1e-10:
                        accels[i] += G * masses_solar[j] * r_vec / (r_mag ** 3)
        return accels
    
    masses_solar = get_masses_solar(bodies_copy)
    
    diag.record_state_from_dicts(
        bodies_copy, timestep=0, time=0.0,
        mass_in_earth_masses=True, star_mass_in_solar=True
    )
    
    if integrator.lower() == "verlet":
        accels = compute_accelerations(bodies_copy, masses_solar)
        
        for step in range(1, n_steps + 1):
            for i, body in enumerate(bodies_copy):
                if "velocity" in body and "position" in body:
                    body["velocity"] = body["velocity"] + accels[i] * dt
                    body["position"] = body["position"] + body["velocity"] * dt
            
            accels = compute_accelerations(bodies_copy, masses_solar)
            current_time += dt
            
            if step % record_interval == 0:
                diag.record_state_from_dicts(
                    bodies_copy, timestep=step, time=current_time,
                    mass_in_earth_masses=True, star_mass_in_solar=True
                )
    
    elif integrator.lower() == "rk4":
        for step in range(1, n_steps + 1):
            positions = [b["position"].copy() for b in bodies_copy]
            velocities = [b["velocity"].copy() for b in bodies_copy]
            
            k1_v = compute_accelerations(bodies_copy, masses_solar)
            k1_x = [v.copy() for v in velocities]
            
            for i, body in enumerate(bodies_copy):
                body["position"] = positions[i] + 0.5 * dt * k1_x[i]
                body["velocity"] = velocities[i] + 0.5 * dt * k1_v[i]
            k2_v = compute_accelerations(bodies_copy, masses_solar)
            k2_x = [b["velocity"].copy() for b in bodies_copy]
            
            for i, body in enumerate(bodies_copy):
                body["position"] = positions[i] + 0.5 * dt * k2_x[i]
                body["velocity"] = velocities[i] + 0.5 * dt * k2_v[i]
            k3_v = compute_accelerations(bodies_copy, masses_solar)
            k3_x = [b["velocity"].copy() for b in bodies_copy]
            
            for i, body in enumerate(bodies_copy):
                body["position"] = positions[i] + dt * k3_x[i]
                body["velocity"] = velocities[i] + dt * k3_v[i]
            k4_v = compute_accelerations(bodies_copy, masses_solar)
            k4_x = [b["velocity"].copy() for b in bodies_copy]
            
            for i, body in enumerate(bodies_copy):
                body["position"] = positions[i] + (dt / 6.0) * (k1_x[i] + 2*k2_x[i] + 2*k3_x[i] + k4_x[i])
                body["velocity"] = velocities[i] + (dt / 6.0) * (k1_v[i] + 2*k2_v[i] + 2*k3_v[i] + k4_v[i])
            
            current_time += dt
            
            if step % record_interval == 0:
                diag.record_state_from_dicts(
                    bodies_copy, timestep=step, time=current_time,
                    mass_in_earth_masses=True, star_mass_in_solar=True
                )
    
    else:
        raise ValueError(f"Unknown integrator: {integrator}. Supported: 'verlet', 'rk4'")
    
    return diag.compute_drift_metrics()


# =============================================================================
# VALIDATION (run with: python -m integrator_diagnostics)
# =============================================================================

if __name__ == "__main__":
    import os
    print("Integrator Diagnostics Validation")
    print("=" * 70)
    
    sun = {
        "name": "Sun",
        "type": "star",
        "mass": 1.0,
        "position": np.array([0.0, 0.0]),
        "velocity": np.array([0.0, 0.0]),
    }
    
    earth_orbital_velocity = np.sqrt(39.478 * 1.0 / 1.0)
    earth = {
        "name": "Earth",
        "type": "planet",
        "mass": 1.0,
        "position": np.array([1.0, 0.0]),
        "velocity": np.array([0.0, earth_orbital_velocity]),
    }
    
    mars_distance = 1.524
    mars_orbital_velocity = np.sqrt(39.478 * 1.0 / mars_distance)
    mars = {
        "name": "Mars",
        "type": "planet",
        "mass": 0.107,
        "position": np.array([mars_distance, 0.0]),
        "velocity": np.array([0.0, mars_orbital_velocity]),
    }
    
    bodies = [sun, earth, mars]
    
    print("\n1. Testing Verlet integrator (1 year, dt=0.001):")
    print("-" * 50)
    metrics_verlet = run_integrator_validation(
        bodies, duration=1.0, dt=0.001, integrator="verlet", record_interval=100
    )
    print(f"  Initial Energy: {metrics_verlet.initial_energy:.6e}")
    print(f"  Final Energy:   {metrics_verlet.final_energy:.6e}")
    print(f"  Max |ΔE/E₀|:    {metrics_verlet.max_energy_drift:.6e}")
    print(f"  Final |ΔE/E₀|:  {metrics_verlet.final_energy_drift:.6e}")
    print(f"  Max |ΔL/L₀|:    {metrics_verlet.max_angular_momentum_drift:.6e}")
    
    if metrics_verlet.max_energy_drift < 1e-3:
        print("  [OK] Verlet energy drift within acceptable range (<1e-3)")
    else:
        print("  [WARN] Verlet energy drift higher than expected")
    
    print("\n2. Testing RK4 integrator (1 year, dt=0.001):")
    print("-" * 50)
    metrics_rk4 = run_integrator_validation(
        bodies, duration=1.0, dt=0.001, integrator="rk4", record_interval=100
    )
    print(f"  Initial Energy: {metrics_rk4.initial_energy:.6e}")
    print(f"  Final Energy:   {metrics_rk4.final_energy:.6e}")
    print(f"  Max |ΔE/E₀|:    {metrics_rk4.max_energy_drift:.6e}")
    print(f"  Final |ΔE/E₀|:  {metrics_rk4.final_energy_drift:.6e}")
    print(f"  Max |ΔL/L₀|:    {metrics_rk4.max_angular_momentum_drift:.6e}")
    
    if metrics_rk4.max_energy_drift < 1e-4:
        print("  [OK] RK4 energy drift within acceptable range (<1e-4)")
    else:
        print("  [WARN] RK4 energy drift higher than expected (may need smaller dt)")
    
    print("\n3. Comparing integrators:")
    print("-" * 50)
    if metrics_rk4.max_energy_drift < metrics_verlet.max_energy_drift:
        print("  [OK] RK4 has lower energy drift than Verlet (as expected for same dt)")
    else:
        print("  [INFO] Verlet has lower or similar drift (both acceptable)")
    
    print("\n4. Testing plot export:")
    print("-" * 50)
    try:
        os.makedirs("exports", exist_ok=True)
        
        diag = IntegratorDiagnostics(G=39.478, record_interval=10)
        
        import copy
        bodies_test = copy.deepcopy(bodies)
        for b in bodies_test:
            b["position"] = np.asarray(b["position"], dtype=np.float64)
            b["velocity"] = np.asarray(b["velocity"], dtype=np.float64)
        
        EARTH_MASS_TO_SOLAR = 1.0 / 333030.0
        G = 39.478
        dt = 0.001
        
        def get_masses_solar(bodies_list):
            masses = []
            for b in bodies_list:
                m = b.get("mass", 0.0)
                if b.get("type") == "star":
                    masses.append(m)
                else:
                    masses.append(m * EARTH_MASS_TO_SOLAR)
            return masses
        
        def compute_accelerations(bodies_list, masses_solar):
            n = len(bodies_list)
            accels = [np.zeros_like(bodies_list[0]["position"]) for _ in range(n)]
            for i in range(n):
                for j in range(n):
                    if i != j:
                        r_vec = bodies_list[j]["position"] - bodies_list[i]["position"]
                        r_mag = np.linalg.norm(r_vec)
                        if r_mag > 1e-10:
                            accels[i] += G * masses_solar[j] * r_vec / (r_mag ** 3)
            return accels
        
        masses_solar = get_masses_solar(bodies_test)
        accels = compute_accelerations(bodies_test, masses_solar)
        
        diag.record_state_from_dicts(bodies_test, timestep=0, time=0.0,
                                      mass_in_earth_masses=True, star_mass_in_solar=True)
        
        for step in range(1, 1001):
            for i, body in enumerate(bodies_test):
                body["velocity"] = body["velocity"] + accels[i] * dt
                body["position"] = body["position"] + body["velocity"] * dt
            accels = compute_accelerations(bodies_test, masses_solar)
            
            if step % 10 == 0:
                diag.record_state_from_dicts(bodies_test, timestep=step, time=step*dt,
                                              mass_in_earth_masses=True, star_mass_in_solar=True)
        
        plot_path = export_energy_drift_plot(
            diag, "exports/integrator_validation_test.png",
            title="Verlet Integrator - Energy Conservation",
            show_angular_momentum=True
        )
        if os.path.exists(plot_path):
            print(f"  [OK] Plot exported to: {plot_path}")
        else:
            print("  [FAIL] Plot file not created")
            
    except ImportError as e:
        print(f"  [SKIP] matplotlib not available: {e}")
    except Exception as e:
        print(f"  [FAIL] Plot export error: {e}")
        import traceback
        traceback.print_exc()
    
    print("\n" + "=" * 70)
    print("Expected Drift Thresholds:")
    print("  Symplectic (Verlet): |ΔE/E₀| should oscillate, not drift. < 1e-6 typical.")
    print("  RK4: Small secular drift. |ΔE/E₀| ~ 1e-8 to 1e-4 depending on dt.")
    print("  Keplerian (kinematic): Energy conserved by construction for 2-body.")
    print("=" * 70)
