"""
Rendering helpers for the main window: color utilities and coordinate transforms.
Scene drawing (orbits, stars, planets, trails, spacetime grid) is invoked from
main_window; complex draw logic can be migrated here incrementally.
"""
from __future__ import annotations

from typing import Tuple


def hex_to_rgb(hex_string: str) -> Tuple[int, int, int]:
    """Convert hex color (e.g. '#FDB813') to RGB tuple."""
    hex_string = hex_string.lstrip("#")
    return tuple(int(hex_string[i : i + 2], 16) for i in (0, 2, 4))


def desaturate_color(
    rgb: Tuple[int, int, int], saturation: float = 0.6
) -> Tuple[int, int, int]:
    """Desaturate RGB by mixing with luminance gray."""
    r, g, b = rgb
    gray = int(0.299 * r + 0.587 * g + 0.114 * b)
    r_d = int(r * saturation + gray * (1.0 - saturation))
    g_d = int(g * saturation + gray * (1.0 - saturation))
    b_d = int(b * saturation + gray * (1.0 - saturation))
    return (r_d, g_d, b_d)
