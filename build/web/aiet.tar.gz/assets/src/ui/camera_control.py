"""
Camera state and coordinate transforms for the main window.
Zoom, pan, and click-to-focus logic. PyInstaller-safe.
"""
from __future__ import annotations

from typing import List, Dict, Any, Optional
import numpy as np


def world_to_screen(pos, zoom: float, offset: List[float]) -> List[float]:
    """Convert world (AU or px) position to screen coordinates."""
    return [
        pos[0] * zoom + offset[0],
        pos[1] * zoom + offset[1],
    ]


def screen_to_world(pos, zoom: float, offset: List[float]) -> List[float]:
    """Convert screen coordinates to world."""
    return [
        (pos[0] - offset[0]) / zoom,
        (pos[1] - offset[1]) / zoom,
    ]


class Camera:
    """
    Holds zoom, pan state and provides coordinate transforms and reset/fit.
    Main window delegates camera state and pan/zoom event handling here.
    """

    def __init__(self, width: int, height: int):
        self.width = width
        self.height = height
        self.zoom = 0.6
        self.offset = [width / 2.0, height / 2.0]
        self.zoom_min = 0.01
        self.zoom_max = 10.0
        self.is_panning = False
        self.pan_start = None
        self.pan_start_offset: Optional[List[float]] = None
        self.last_zoom_for_orbits = 1.0
        self.camera_focus = {
            "active": False,
            "target_body_id": None,
            "target_world_pos": None,
            "target_zoom": None,
        }

    def set_size(self, width: int, height: int):
        self.width = width
        self.height = height

    def world_to_screen(self, pos) -> List[float]:
        return world_to_screen(pos, self.zoom, self.offset)

    def screen_to_world(self, pos) -> List[float]:
        return screen_to_world(pos, self.zoom, self.offset)

    def reset_camera(self, placed_bodies: List[Dict[str, Any]]) -> None:
        """Reset to default view (zoom=0.6, centered on Sun)."""
        self.zoom = 0.6
        sun = next(
            (b for b in placed_bodies if b.get("name") == "Sun" and b.get("type") == "star"),
            None,
        )
        if sun:
            sun_pos = sun["position"]
            screen_cx = self.width / 2
            screen_cy = self.height / 2
            self.offset = [
                screen_cx - sun_pos[0] * self.zoom,
                screen_cy - sun_pos[1] * self.zoom,
            ]
        else:
            self.offset = [self.width / 2.0, self.height / 2.0]
        self.camera_focus["active"] = False

    def camera_fit_furthest_planet(self, placed_bodies: List[Dict[str, Any]]) -> None:
        """Pan/zoom so furthest planet is in view with star centred."""
        star = next((b for b in placed_bodies if b.get("type") == "star"), None)
        if not star:
            return
        star_id = star.get("id")
        star_name = star.get("name")
        star_pos = np.array(star["position"])
        planets = [
            b
            for b in placed_bodies
            if b.get("type") == "planet"
            and (b.get("parent_id") == star_id or b.get("parent") == star_name)
        ]
        if not planets:
            self.reset_camera(placed_bodies)
            return
        max_dist = max(
            float(np.linalg.norm(np.array(p["position"]) - star_pos)) for p in planets
        )
        if max_dist < 1e-6:
            self.reset_camera(placed_bodies)
            return
        view_size = min(self.width, self.height) * 0.9
        fit_zoom = view_size / (2.0 * max_dist * 1.25)
        fit_zoom = max(self.zoom_min, min(self.zoom_max, fit_zoom))
        self.zoom = fit_zoom
        screen_cx = self.width / 2
        screen_cy = self.height / 2
        self.offset[0] = screen_cx - star_pos[0] * fit_zoom
        self.offset[1] = screen_cy - star_pos[1] * fit_zoom
        self.camera_focus["active"] = False
