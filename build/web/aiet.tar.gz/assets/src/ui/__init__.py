# UI: main window, diagnostics panel, camera, renderer
