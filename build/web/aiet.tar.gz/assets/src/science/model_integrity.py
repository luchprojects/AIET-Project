"""
AIET Unified Model Integrity & Validation Report System

Combines Monte Carlo uncertainty diagnostics and integrator validation into
a single structured report representing the scientific trustworthiness of a run.

This module provides:
    - ModelIntegrityReport: Unified dataclass for all validation metrics
    - Threshold evaluation for automated pass/fail flags
    - generate_model_integrity_report(): Orchestrator function
    - Export functions for JSON (and future PDF)

Key Concepts:
    1. SAMPLING CONVERGENCE: Measures stability of Monte Carlo estimation.
       - standard_error: Sampling uncertainty of the mean (std/sqrt(N))
       - convergence_delta: Change in running mean between checkpoints
       - These measure HOW WELL we estimated the mean, not model correctness.

    2. PHYSICAL CONSERVATION: Measures integrator numerical stability.
       - energy_drift: Violation of energy conservation (should be ~0)
       - angular_momentum_drift: Violation of L conservation (should be ~0)
       - These measure NUMERICAL ACCURACY of the orbital integrator.

    3. FLAGS: Boolean indicators of whether thresholds are met.
       - uncertainty_converged: MC sampling has stabilized
       - sampling_stable: Standard error is acceptably small
       - energy_conserved: Energy drift within integrator tolerance
       - angular_momentum_conserved: L drift within tolerance

Limitations:
    - Does NOT validate model correctness (only numerical stability)
    - Does NOT capture epistemic uncertainty of the ML model
    - Thresholds are heuristics, not absolute physical requirements
    - Integrator validation requires N-body simulation data

Usage:
    from model_integrity import generate_model_integrity_report, export_integrity_report_json

    report = generate_model_integrity_report(
        calculator=ml_calc,
        planet_data=planet_dict,
        bodies=simulation_bodies,
        integrator_duration=1.0,
        integrator_dt=0.001,
    )
    export_integrity_report_json(report, "exports/integrity_report.json")
"""

from __future__ import annotations

import json
import os
from dataclasses import dataclass, field, asdict
from datetime import datetime
from typing import Dict, List, Optional, Any, Tuple

import numpy as np


# =============================================================================
# DEFAULT THRESHOLDS
# =============================================================================

# Monte Carlo / Uncertainty thresholds
UNCERTAINTY_SE_THRESHOLD = 1.0      # Standard error should be < 1.0 index points
CONVERGENCE_THRESHOLD = 0.5         # Running mean delta should be < 0.5 index points

# Integrator energy conservation thresholds (relative drift |ΔE/E₀|)
VERLET_ENERGY_TOL = 1e-6            # Symplectic integrators should not drift
RK4_ENERGY_TOL = 1e-4               # RK4 has small secular drift

# Angular momentum conservation threshold
ANG_MOM_TOL = 1e-6                  # Should be conserved in isolated systems


# =============================================================================
# MODEL INTEGRITY REPORT DATACLASS
# =============================================================================

@dataclass
class ModelIntegrityReport:
    """
    Unified validation report combining MC uncertainty and integrator diagnostics.
    
    Attributes:
        # Monte Carlo Uncertainty Results
        mean_index: Mean habitability index from MC sampling (0-100 scale).
        std_dev: Standard deviation of MC samples.
        ci_lower: Lower bound of 95% confidence interval.
        ci_upper: Upper bound of 95% confidence interval.
        standard_error: Sampling uncertainty of the mean (std_dev / sqrt(N)).
        convergence_delta: Absolute change between last two running mean checkpoints.
        converged_early: True if MC stopped early due to tolerance.
        sample_count: Number of MC samples used.
        
        # Integrator Diagnostics
        max_energy_drift: Maximum |ΔE/E₀| observed during simulation.
        final_energy_drift: Final |ΔE/E₀| at end of simulation.
        max_angular_momentum_drift: Maximum |ΔL/L₀| observed.
        final_angular_momentum_drift: Final |ΔL/L₀| at end of simulation.
        integrator_type: Type of integrator used ("verlet", "rk4", "keplerian", etc.).
        integrator_steps: Number of integration steps performed.
        integrator_duration: Total simulation time for validation.
        
        # Validation Flags
        flags: Dictionary of boolean pass/fail indicators:
            - uncertainty_converged: MC running mean has stabilized
            - sampling_stable: Standard error is within threshold
            - energy_conserved: Energy drift within integrator tolerance
            - angular_momentum_conserved: L drift within tolerance
            - all_checks_passed: All flags are True
        
        # Metadata
        timestamp: ISO timestamp of report generation.
        planet_name: Name of planet being validated (if available).
        thresholds_used: Dictionary of threshold values used for evaluation.
    """
    
    # Monte Carlo results
    mean_index: float
    std_dev: float
    ci_lower: float
    ci_upper: float
    standard_error: float
    convergence_delta: float
    converged_early: bool
    sample_count: int
    
    # Integrator diagnostics
    max_energy_drift: float
    final_energy_drift: float
    max_angular_momentum_drift: float
    final_angular_momentum_drift: float
    integrator_type: str
    integrator_steps: int
    integrator_duration: float
    
    # Validation flags
    flags: Dict[str, bool] = field(default_factory=dict)
    
    # Metadata
    timestamp: str = ""
    planet_name: str = ""
    thresholds_used: Dict[str, float] = field(default_factory=dict)
    
    # Optional: running means for diagnostics
    running_means: List[Tuple[int, float]] = field(default_factory=list)
    
    def __post_init__(self):
        if not self.timestamp:
            self.timestamp = datetime.now().isoformat()
    
    def is_valid(self) -> bool:
        """Return True if all validation checks passed."""
        return self.flags.get("all_checks_passed", False)
    
    def summary(self) -> str:
        """Return human-readable summary of validation status."""
        lines = [
            f"Model Integrity Report - {self.planet_name or 'Unknown Planet'}",
            "=" * 60,
            "",
            "Monte Carlo Uncertainty:",
            f"  Mean Index: {self.mean_index:.2f} ± {self.std_dev:.2f}",
            f"  95% CI: [{self.ci_lower:.2f}, {self.ci_upper:.2f}]",
            f"  Standard Error: {self.standard_error:.4f}",
            f"  Convergence Delta: {self.convergence_delta:.4f}",
            f"  Samples: {self.sample_count}" + (" (early stop)" if self.converged_early else ""),
            "",
            "Integrator Diagnostics:",
            f"  Type: {self.integrator_type}",
            f"  Max Energy Drift: {self.max_energy_drift:.2e}",
            f"  Final Energy Drift: {self.final_energy_drift:.2e}",
            f"  Max Angular Momentum Drift: {self.max_angular_momentum_drift:.2e}",
            f"  Steps: {self.integrator_steps}, Duration: {self.integrator_duration}",
            "",
            "Validation Flags:",
        ]
        
        for flag_name, flag_value in self.flags.items():
            status = "✓ PASS" if flag_value else "✗ FAIL"
            lines.append(f"  {flag_name}: {status}")
        
        lines.append("")
        lines.append(f"Overall: {'VALID' if self.is_valid() else 'INVALID'}")
        lines.append(f"Generated: {self.timestamp}")
        
        return "\n".join(lines)


# =============================================================================
# THRESHOLD EVALUATION
# =============================================================================

def evaluate_thresholds(
    mc_result: Dict[str, Any],
    drift_metrics: Optional[Any] = None,
    integrator_type: str = "verlet",
    se_threshold: float = UNCERTAINTY_SE_THRESHOLD,
    convergence_threshold: float = CONVERGENCE_THRESHOLD,
    verlet_energy_tol: float = VERLET_ENERGY_TOL,
    rk4_energy_tol: float = RK4_ENERGY_TOL,
    ang_mom_tol: float = ANG_MOM_TOL,
) -> Tuple[Dict[str, bool], Dict[str, float]]:
    """
    Evaluate validation thresholds and return flags.
    
    Args:
        mc_result: Dict from run_monte_carlo() or predict_with_uncertainty().
        drift_metrics: DriftMetrics object from integrator validation (optional).
        integrator_type: Type of integrator ("verlet", "rk4", "keplerian").
        se_threshold: Max acceptable standard error.
        convergence_threshold: Max acceptable convergence delta.
        verlet_energy_tol: Energy drift tolerance for Verlet integrator.
        rk4_energy_tol: Energy drift tolerance for RK4 integrator.
        ang_mom_tol: Angular momentum drift tolerance.
        
    Returns:
        Tuple of (flags dict, thresholds dict).
    """
    flags = {}
    thresholds = {
        "uncertainty_se_threshold": se_threshold,
        "convergence_threshold": convergence_threshold,
        "verlet_energy_tol": verlet_energy_tol,
        "rk4_energy_tol": rk4_energy_tol,
        "ang_mom_tol": ang_mom_tol,
    }
    
    # MC convergence flags
    standard_error = mc_result.get("standard_error", float("inf"))
    convergence_delta = mc_result.get("convergence_delta", float("inf"))
    
    flags["sampling_stable"] = standard_error < se_threshold
    flags["uncertainty_converged"] = convergence_delta < convergence_threshold
    
    # Integrator flags (default to True if no integrator data)
    if drift_metrics is not None:
        max_energy_drift = getattr(drift_metrics, "max_energy_drift", 0.0)
        max_ang_mom_drift = getattr(drift_metrics, "max_angular_momentum_drift", 0.0)
        
        if integrator_type.lower() in ("verlet", "leapfrog", "symplectic"):
            energy_tol = verlet_energy_tol
        elif integrator_type.lower() == "rk4":
            energy_tol = rk4_energy_tol
        else:
            energy_tol = rk4_energy_tol
        
        flags["energy_conserved"] = max_energy_drift < energy_tol
        flags["angular_momentum_conserved"] = max_ang_mom_drift < ang_mom_tol
        thresholds["energy_tol_used"] = energy_tol
    else:
        flags["energy_conserved"] = True
        flags["angular_momentum_conserved"] = True
        thresholds["energy_tol_used"] = 0.0
    
    flags["all_checks_passed"] = all(flags.values())
    
    return flags, thresholds


# =============================================================================
# ORCHESTRATOR FUNCTION
# =============================================================================

def generate_model_integrity_report(
    calculator: Any,
    planet_data: Dict[str, Any],
    star_data: Optional[Dict[str, Any]] = None,
    bodies: Optional[List[Dict[str, Any]]] = None,
    planet_name: str = "",
    mc_samples: int = 1000,
    mc_seed: Optional[int] = None,
    mc_tolerance: Optional[float] = None,
    mc_checkpoint_interval: int = 50,
    integrator_duration: float = 1.0,
    integrator_dt: float = 0.001,
    integrator_type: str = "verlet",
    integrator_record_interval: int = 10,
    run_integrator: bool = True,
    se_threshold: float = UNCERTAINTY_SE_THRESHOLD,
    convergence_threshold: float = CONVERGENCE_THRESHOLD,
) -> ModelIntegrityReport:
    """
    Generate unified model integrity report.
    
    This orchestrator function:
    1. Runs predict_with_uncertainty() for Monte Carlo diagnostics
    2. Optionally runs run_integrator_validation() for energy conservation
    3. Evaluates thresholds and computes validation flags
    4. Returns a unified ModelIntegrityReport
    
    Args:
        calculator: MLHabitabilityCalculatorV4 instance.
        planet_data: NASA-style planet dict for MC uncertainty.
        star_data: Optional star dict (merged with planet_data if None).
        bodies: List of body dicts for integrator validation.
            If None, integrator validation is skipped.
        planet_name: Name of planet for report metadata.
        mc_samples: Number of Monte Carlo samples (default 1000).
        mc_seed: Random seed for reproducibility.
        mc_tolerance: Optional MC convergence tolerance for early stopping.
        mc_checkpoint_interval: MC running mean checkpoint interval.
        integrator_duration: Duration for integrator validation (in years).
        integrator_dt: Time step for integrator validation.
        integrator_type: Integrator type ("verlet" or "rk4").
        integrator_record_interval: Record interval for integrator diagnostics.
        run_integrator: If False, skip integrator validation entirely.
        se_threshold: Standard error threshold for validation.
        convergence_threshold: Convergence delta threshold for validation.
        
    Returns:
        ModelIntegrityReport with all diagnostics and validation flags.
        
    Raises:
        ImportError: If required modules are not available.
    """
    try:
        from src.ml.ml_habitability import MLHabitabilityCalculator
    except ImportError:
        MLHabitabilityCalculatorV4 = None
    
    mc_result = calculator.predict_with_uncertainty(
        planet_data=planet_data,
        star_data=star_data,
        N=mc_samples,
        seed=mc_seed,
        tolerance=mc_tolerance,
        checkpoint_interval=mc_checkpoint_interval,
    )
    
    drift_metrics = None
    integrator_steps = 0
    
    if run_integrator and bodies is not None and len(bodies) > 0:
        try:
            from src.physics.integrator_diagnostics import run_integrator_validation
            
            drift_metrics = run_integrator_validation(
                bodies=bodies,
                duration=integrator_duration,
                dt=integrator_dt,
                integrator=integrator_type,
                record_interval=integrator_record_interval,
            )
            integrator_steps = drift_metrics.total_timesteps
        except ImportError:
            print("[ModelIntegrity] integrator_diagnostics not available, skipping integrator validation")
        except Exception as e:
            print(f"[ModelIntegrity] Integrator validation failed: {e}")
    
    flags, thresholds = evaluate_thresholds(
        mc_result=mc_result,
        drift_metrics=drift_metrics,
        integrator_type=integrator_type,
        se_threshold=se_threshold,
        convergence_threshold=convergence_threshold,
    )
    
    report = ModelIntegrityReport(
        mean_index=mc_result.get("mean_index", 0.0),
        std_dev=mc_result.get("std_dev", 0.0),
        ci_lower=mc_result.get("ci_lower", 0.0),
        ci_upper=mc_result.get("ci_upper", 0.0),
        standard_error=mc_result.get("standard_error", 0.0),
        convergence_delta=mc_result.get("convergence_delta", 0.0),
        converged_early=mc_result.get("converged_early", False),
        sample_count=mc_result.get("sample_count", mc_result.get("samples", 0)),
        
        max_energy_drift=drift_metrics.max_energy_drift if drift_metrics else 0.0,
        final_energy_drift=drift_metrics.final_energy_drift if drift_metrics else 0.0,
        max_angular_momentum_drift=drift_metrics.max_angular_momentum_drift if drift_metrics else 0.0,
        final_angular_momentum_drift=drift_metrics.final_angular_momentum_drift if drift_metrics else 0.0,
        integrator_type=integrator_type,
        integrator_steps=integrator_steps,
        integrator_duration=integrator_duration if (run_integrator and bodies) else 0.0,
        
        flags=flags,
        planet_name=planet_name,
        thresholds_used=thresholds,
        running_means=mc_result.get("running_means", []),
    )
    
    return report


# =============================================================================
# EXPORT FUNCTIONS
# =============================================================================

def export_integrity_report_json(
    report: ModelIntegrityReport,
    output_path: str,
    indent: int = 2,
) -> str:
    """
    Export ModelIntegrityReport to JSON file.
    
    Args:
        report: ModelIntegrityReport instance.
        output_path: Path to save JSON file.
        indent: JSON indentation (default 2).
        
    Returns:
        Path to saved file.
    """
    os.makedirs(os.path.dirname(output_path) or ".", exist_ok=True)
    
    report_dict = asdict(report)
    
    running_means = report_dict.get("running_means", [])
    if running_means:
        report_dict["running_means"] = [
            {"sample_count": rm[0], "mean": rm[1]} for rm in running_means
        ]
    
    with open(output_path, 'w') as f:
        json.dump(report_dict, f, indent=indent, default=str)
    
    print(f"[ModelIntegrity] Exported report to: {output_path}")
    return output_path


def export_integrity_report_summary(
    report: ModelIntegrityReport,
    output_path: str,
) -> str:
    """
    Export human-readable summary to text file.
    
    Args:
        report: ModelIntegrityReport instance.
        output_path: Path to save text file.
        
    Returns:
        Path to saved file.
    """
    os.makedirs(os.path.dirname(output_path) or ".", exist_ok=True)
    
    with open(output_path, 'w') as f:
        f.write(report.summary())
    
    print(f"[ModelIntegrity] Exported summary to: {output_path}")
    return output_path


# =============================================================================
# QUICK VALIDATION HELPER
# =============================================================================

def quick_validate_prediction(
    calculator: Any,
    planet_data: Dict[str, Any],
    star_data: Optional[Dict[str, Any]] = None,
    mc_samples: int = 500,
    verbose: bool = True,
) -> Tuple[bool, ModelIntegrityReport]:
    """
    Quick validation helper for interactive use.
    
    Runs MC uncertainty validation (no integrator) and returns pass/fail.
    
    Args:
        calculator: MLHabitabilityCalculatorV4 instance.
        planet_data: NASA-style planet dict.
        star_data: Optional star dict.
        mc_samples: Number of MC samples (default 500 for speed).
        verbose: If True, print summary.
        
    Returns:
        Tuple of (is_valid, report).
    """
    report = generate_model_integrity_report(
        calculator=calculator,
        planet_data=planet_data,
        star_data=star_data,
        mc_samples=mc_samples,
        run_integrator=False,
    )
    
    if verbose:
        print(report.summary())
    
    return report.is_valid(), report


# =============================================================================
# VALIDATION (run with: python -m model_integrity)
# =============================================================================

if __name__ == "__main__":
    import sys
    print("Model Integrity & Validation Report System")
    print("=" * 70)
    
    try:
        from src.ml.ml_habitability import MLHabitabilityCalculator
    except ImportError as e:
        print(f"Skip: {e}")
        sys.exit(0)
    
    calc = MLHabitabilityCalculatorV4()
    
    earth = {
        "pl_rade": 1.0, "pl_masse": 1.0, "pl_orbper": 365.25,
        "pl_orbsmax": 1.0, "pl_orbeccen": 0.0167, "pl_insol": 1.0,
        "pl_eqt": 255.0, "pl_dens": 5.51,
        "st_teff": 5778.0, "st_mass": 1.0, "st_rad": 1.0, "st_lum": 1.0,
    }
    
    sun = {
        "name": "Sun",
        "type": "star",
        "mass": 1.0,
        "position": np.array([0.0, 0.0]),
        "velocity": np.array([0.0, 0.0]),
    }
    
    earth_orbital_velocity = np.sqrt(39.478 * 1.0 / 1.0)
    earth_body = {
        "name": "Earth",
        "type": "planet",
        "mass": 1.0,
        "position": np.array([1.0, 0.0]),
        "velocity": np.array([0.0, earth_orbital_velocity]),
    }
    
    bodies = [sun, earth_body]
    
    print("\n1. Generating full integrity report (MC + Integrator):")
    print("-" * 50)
    
    report = generate_model_integrity_report(
        calculator=calc,
        planet_data=earth,
        bodies=bodies,
        planet_name="Earth",
        mc_samples=500,
        mc_seed=42,
        integrator_duration=1.0,
        integrator_dt=0.001,
        integrator_type="verlet",
    )
    
    print(report.summary())
    
    print("\n2. Testing JSON export:")
    print("-" * 50)
    
    os.makedirs("exports", exist_ok=True)
    json_path = export_integrity_report_json(report, "exports/integrity_test.json")
    
    if os.path.exists(json_path):
        print(f"[OK] JSON exported to: {json_path}")
        with open(json_path, 'r') as f:
            loaded = json.load(f)
        assert "mean_index" in loaded
        assert "flags" in loaded
        print("[OK] JSON structure verified")
    else:
        print("[FAIL] JSON not created")
    
    print("\n3. Testing quick validation:")
    print("-" * 50)
    
    is_valid, quick_report = quick_validate_prediction(
        calc, earth, mc_samples=200, verbose=False
    )
    print(f"Quick validation result: {'VALID' if is_valid else 'INVALID'}")
    print(f"  Mean: {quick_report.mean_index:.2f} ± {quick_report.std_dev:.2f}")
    print(f"  SE: {quick_report.standard_error:.4f}")
    
    print("\n4. Testing threshold evaluation:")
    print("-" * 50)
    
    mock_mc = {
        "mean_index": 95.0,
        "std_dev": 3.0,
        "standard_error": 0.5,
        "convergence_delta": 0.1,
    }
    
    flags_pass, _ = evaluate_thresholds(mock_mc, None)
    print(f"Good MC result: sampling_stable={flags_pass['sampling_stable']}, "
          f"uncertainty_converged={flags_pass['uncertainty_converged']}")
    
    mock_mc_bad = {
        "mean_index": 95.0,
        "std_dev": 10.0,
        "standard_error": 2.0,
        "convergence_delta": 1.5,
    }
    
    flags_fail, _ = evaluate_thresholds(mock_mc_bad, None)
    print(f"Bad MC result: sampling_stable={flags_fail['sampling_stable']}, "
          f"uncertainty_converged={flags_fail['uncertainty_converged']}")
    
    if flags_pass['sampling_stable'] and not flags_fail['sampling_stable']:
        print("[OK] Threshold evaluation working correctly")
    else:
        print("[FAIL] Threshold evaluation not working")
    
    print("\n" + "=" * 70)
    print("Threshold Documentation:")
    print(f"  UNCERTAINTY_SE_THRESHOLD = {UNCERTAINTY_SE_THRESHOLD}")
    print(f"  CONVERGENCE_THRESHOLD = {CONVERGENCE_THRESHOLD}")
    print(f"  VERLET_ENERGY_TOL = {VERLET_ENERGY_TOL}")
    print(f"  RK4_ENERGY_TOL = {RK4_ENERGY_TOL}")
    print(f"  ANG_MOM_TOL = {ANG_MOM_TOL}")
    print("=" * 70)
