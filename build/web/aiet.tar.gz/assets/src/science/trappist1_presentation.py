"""
TRAPPIST-1 presentation figures: N-body energy stability + ML SHAP explainability.

Run from repo root:
    python -m src.science.trappist1_presentation

Outputs (default ./exports/trappist1_presentation/):
    - trappist1_energy_total.png / .jpg — ΔE/E₀ vs time (zero baseline; poster-friendly)
    - trappist1_shap/              — SHAP waterfalls with plain-English feature labels (requires shap)

Energy plot: title "Hamiltonian Stability: Zero Energy Leakage." — y-axis is relative deviation only.

NASA Archive → English (y-axis labels on SHAP figures):
    pl_rade   Planet radius (Earth radii)
    pl_masse  Planet mass (Earth masses)
    pl_orbper Orbital period (days)
    pl_orbsmax Distance from star — semi-major axis (AU)
    pl_orbeccen Orbital eccentricity
    pl_insol  Stellar insolation (Earth flux = 1)
    pl_eqt    Equilibrium temperature (K)
    pl_dens   Planet bulk density (g/cm³)
    st_teff   Stellar effective temperature (K)
    st_mass   Stellar mass (solar masses)
    st_rad    Stellar radius (solar radii)
    st_lum    Stellar luminosity (solar luminosities)

SHAP x-axis: contributions are in the same units as the model output (raw score 0–1). The UI’s
“%” index is Earth-normalized: (raw / Earth_raw) × 100 (Earth ≈ 100%).

Uses the same SimulationEngine leapfrog + Hamiltonian as the sandbox N-body path.
"""

from __future__ import annotations

import os
import sys
from typing import Any, Dict, List, Optional, Tuple
from uuid import uuid4

import numpy as np

EXPORT_DPI = 600

# Repo root on path when running as script
_REPO_ROOT = os.path.abspath(os.path.join(os.path.dirname(__file__), "..", ".."))
if _REPO_ROOT not in sys.path:
    sys.path.insert(0, _REPO_ROOT)


def _exports_dir() -> str:
    d = os.path.join(_REPO_ROOT, "exports", "trappist1_presentation")
    os.makedirs(d, exist_ok=True)
    return d


def _set_publication_style() -> None:
    """NASA/STScI-like plot defaults."""
    import matplotlib as mpl

    mpl.rcParams.update(
        {
            "font.family": "serif",
            "font.serif": ["Computer Modern Roman", "CMU Serif", "DejaVu Serif"],
            "font.size": 11,
            "axes.titlesize": 14,
            "axes.labelsize": 12,
            "xtick.labelsize": 10,
            "ytick.labelsize": 10,
            "legend.fontsize": 10,
            "axes.titlelocation": "center",
            "mathtext.fontset": "cm",
            "figure.dpi": EXPORT_DPI,
            "savefig.dpi": EXPORT_DPI,
        }
    )


# NASA Archive column names → short English labels for SHAP / posters
NASA_FEATURE_DISPLAY_NAMES: Dict[str, str] = {
    "pl_rade": "Planet radius (Earth radii)",
    "pl_masse": "Planet mass (Earth masses)",
    "pl_orbper": "Orbital period (days)",
    "pl_orbsmax": "Distance from star — semi-major axis (AU)",
    "pl_orbeccen": "Orbital eccentricity",
    "pl_insol": "Stellar insolation (Earth flux = 1)",
    "pl_eqt": "Equilibrium temperature (K)",
    "pl_dens": "Planet bulk density (g/cm³)",
    "st_teff": "Stellar effective temperature (K)",
    "st_mass": "Stellar mass (solar masses)",
    "st_rad": "Stellar radius (solar radii)",
    "st_lum": "Stellar luminosity (solar luminosities)",
}


def _display_feature_names(schema_names: List[str]) -> List[str]:
    return [NASA_FEATURE_DISPLAY_NAMES.get(n, n) for n in schema_names]


def _format_feature_value(raw_name: str, value: float) -> str:
    """Format NASA feature values for dual-labeled SHAP bars."""
    if raw_name == "pl_insol":
        return f"{value:.2f}x Earth"
    if raw_name == "pl_rade":
        return f"{value:.2f} R⊕"
    if raw_name == "pl_masse":
        return f"{value:.2f} M⊕"
    if raw_name == "pl_eqt":
        return f"{value:.0f} K"
    if raw_name == "pl_orbper":
        return f"{value:.2f} d"
    if raw_name == "pl_orbsmax":
        return f"{value:.4f} AU"
    if raw_name == "pl_orbeccen":
        return f"{value:.3f}"
    if raw_name == "pl_dens":
        return f"{value:.2f} g/cm³"
    if raw_name == "st_teff":
        return f"{value:.0f} K"
    if raw_name == "st_mass":
        return f"{value:.3f} M☉"
    if raw_name == "st_rad":
        return f"{value:.3f} R☉"
    if raw_name == "st_lum":
        return f"{value:.6f} L☉"
    return f"{value:.3g}"


def build_trappist_bodies_for_nbody(
    scale_px_per_au: float = 400.0,
    screen_w: float = 800.0,
    screen_h: float = 600.0,
) -> List[Dict[str, Any]]:
    """
    Minimal placed_bodies-style dicts for SimulationEngine._initialize_nbody_state.
    Star at screen center; planets on nested orbits with distinct phases.
    """
    from src.physics.system_presets import get_trappist1_system

    cx, cy = screen_w / 2.0, screen_h / 2.0
    specs = get_trappist1_system()
    type_order = {"star": 0, "planet": 1, "moon": 2}
    specs_sorted = sorted(specs, key=lambda s: type_order.get(s.get("type", "planet"), 1))

    bodies: List[Dict[str, Any]] = []
    stars_by_name: Dict[str, Any] = {}
    planet_index = 0
    n_planets = sum(1 for s in specs_sorted if s.get("type") == "planet")

    for spec in specs_sorted:
        bt = spec.get("type")
        name = spec.get("name", "")
        if bt == "star":
            bid = str(uuid4())
            star: Dict[str, Any] = {
                "id": bid,
                "type": "star",
                "name": name,
                "mass": float(spec.get("mass", 0.089)),
                "radius": float(spec.get("radius", 0.121)),
                "position": np.array([cx, cy], dtype=float),
                "velocity": np.array([0.0, 0.0], dtype=float),
                "temperature": float(spec.get("temperature", 2550.0)),
                "luminosity": float(spec.get("luminosity", 5.5e-4)),
                "is_destroyed": False,
            }
            stars_by_name[name] = star
            bodies.append(star)
        elif bt == "planet":
            host_name = spec.get("host_star", "TRAPPIST-1")
            host = stars_by_name.get(host_name)
            if host is None:
                continue
            bid = str(uuid4())
            a_au = float(spec.get("semi_major_axis", 0.02))
            e = float(spec.get("eccentricity", 0.01))
            theta = 2.0 * np.pi * (planet_index / max(n_planets, 1))
            planet_index += 1
            planet: Dict[str, Any] = {
                "id": bid,
                "type": "planet",
                "name": name,
                "mass": float(spec.get("mass", 1.0)),
                "radius": float(spec.get("radius", 1.0)),
                "position": np.array([cx, cy], dtype=float),
                "velocity": np.array([0.0, 0.0], dtype=float),
                "semiMajorAxis": a_au,
                "eccentricity": e,
                "orbit_angle": float(theta),
                "parent": host.get("name"),
                "parent_id": host.get("id"),
                "parent_obj": host,
                "is_destroyed": False,
            }
            bodies.append(planet)

    return bodies


def run_trappist_energy_trace(
    duration_years: float = 100.0,
    dt_years: float = 0.01,
    n_substeps: int = 20,
    scale_px_per_au: float = 400.0,
    record_every_outer_steps: int = 25,
) -> Tuple[np.ndarray, np.ndarray, np.ndarray, Dict[str, Any]]:
    """
    Integrate TRAPPIST-1 (star + 7 planets) with leapfrog; return time series of energy.

    Returns:
        t_years: time samples
        E_total: total Hamiltonian energy (AU, year, M_sun units)
        rel_drift: (E - E0) / E0
        meta: step counts and parameters for captions
    """
    from src.physics.simulation_engine import SimulationEngine

    bodies = build_trappist_bodies_for_nbody(scale_px_per_au=scale_px_per_au)
    engine = SimulationEngine()
    engine._nbody_substeps = n_substeps
    engine._initialize_nbody_state(bodies, scale_px_per_au)

    n_outer = int(max(1, np.ceil(duration_years / dt_years)))
    times: List[float] = []
    energies: List[float] = []
    E0: Optional[float] = None

    for step in range(n_outer + 1):
        if step > 0:
            engine.step_nbody(dt_years, bodies, n_sub=n_substeps, scale_px_per_au=scale_px_per_au)

        if step % record_every_outer_steps != 0 and step != n_outer:
            continue

        N = len(bodies)
        pos = np.zeros((N, 2))
        vel = np.zeros((N, 2))
        mass = np.zeros(N)
        for i, b in enumerate(bodies):
            pos[i] = np.asarray(b.get("position_au"), dtype=float).reshape(2)
            vel[i] = np.asarray(b.get("velocity_au"), dtype=float).reshape(2)
            mass[i] = engine._mass_solar(b)
        E = engine._total_energy_nbody(pos, vel, mass, bodies)
        if E0 is None:
            E0 = E
        t = step * dt_years
        times.append(t)
        energies.append(E)

    t_arr = np.array(times, dtype=np.float64)
    E_arr = np.array(energies, dtype=np.float64)
    if E0 is not None and abs(E0) > 1e-30:
        rel = (E_arr - E0) / E0
    else:
        rel = E_arr - E_arr[0]

    total_substeps = n_outer * n_substeps
    meta = {
        "duration_years": duration_years,
        "dt_years": dt_years,
        "n_outer_steps": n_outer,
        "n_substeps": n_substeps,
        "total_leapfrog_substeps": total_substeps,
        "E0": E0,
        "max_abs_rel_drift": float(np.max(np.abs(rel))) if len(rel) else 0.0,
    }
    return t_arr, E_arr, rel, meta


def export_energy_plot(
    out_path: Optional[str] = None,
    duration_years: float = 100.0,
    **kwargs: Any,
) -> str:
    """
    Single-panel figure: relative energy deviation ΔE/E₀ vs time (stability obvious vs. a zero baseline).
    Also writes a .jpg copy for posters when Pillow is available.
    """
    try:
        import matplotlib

        matplotlib.use("Agg")
        import matplotlib.pyplot as plt
        import matplotlib.ticker as mticker
    except ImportError as e:
        raise ImportError("matplotlib is required for export_energy_plot") from e

    _set_publication_style()
    t_arr, _E_arr, rel, meta = run_trappist_energy_trace(duration_years=duration_years, **kwargs)
    if out_path is None:
        out_path = os.path.join(_exports_dir(), "trappist1_energy_total.png")

    fig, ax = plt.subplots(1, 1, figsize=(12, 8), facecolor="white")
    ax.set_facecolor("white")

    # Zoom y-axis around zero so oscillations are visible (not a misleading “flat” line at huge |E|)
    rel = np.asarray(rel, dtype=np.float64)
    max_abs = float(np.max(np.abs(rel))) if rel.size else 0.0
    pad = max(max_abs * 0.25, 1e-18)
    y_lo, y_hi = -max_abs - pad, max_abs + pad
    if max_abs < 1e-30:
        y_lo, y_hi = -1e-15, 1e-15

    ax.axhspan(-6.0e-6, 2.0e-6, color="#4CAF50", alpha=0.14, zorder=0, label="Stability corridor")
    ax.plot(t_arr, rel, color="#0f4c81", linewidth=1.8, label=r"$\Delta E / E_0$")
    ax.axhline(0.0, color="#111111", linestyle="-", linewidth=2.2, zorder=1, label="Zero-drift reference")
    ax.set_ylim(y_lo, y_hi)
    ax.set_xlabel("Simulated time (years)", fontsize=11, loc="center")
    ax.set_ylabel(r"Relative energy deviation $\Delta E / E_0$  (×10$^{-6}$)", fontsize=11)
    ax.yaxis.set_major_formatter(mticker.FuncFormatter(lambda y, _pos: f"{y*1e6:.2f}"))
    ax.grid(True, alpha=0.35, linestyle="-", linewidth=0.5)
    ax.legend(loc="upper left", bbox_to_anchor=(0.02, 0.98), framealpha=0.97)

    ax.set_title(
        "Hamiltonian Stability: Zero Energy Leakage.",
        fontsize=13,
        fontweight="bold",
        pad=12,
        loc="center",
    )
    ax.text(
        0.5,
        -0.18,
        "TRAPPIST-1 — star + 7 planets — symplectic leapfrog N-body (same Hamiltonian as AIET)",
        transform=ax.transAxes,
        ha="center",
        fontsize=9,
        color="#444444",
    )

    nsub = meta.get("total_leapfrog_substeps", 0)
    mad = meta.get("max_abs_rel_drift", 0.0)
    audit_text = (
        "Physics Audit\n"
        f"Substeps: {nsub:,}\n"
        f"Outer Δt: {meta.get('dt_years', 0)} yr\n"
        f"Substeps/outer: {meta.get('n_substeps', 0)}\n"
        f"Max |ΔE/E₀|: {mad:.2e}"
    )
    ax.text(
        0.955,
        0.075,
        audit_text,
        transform=ax.transAxes,
        ha="right",
        va="bottom",
        fontsize=9,
        color="#2f2f2f",
        bbox=dict(boxstyle="round,pad=0.35", fc="white", ec="#7f8c8d", alpha=0.95),
    )

    plt.tight_layout(rect=[0, 0.06, 1, 1])
    fig.savefig(out_path, dpi=EXPORT_DPI, facecolor="white", bbox_inches="tight")

    jpg_path = os.path.splitext(out_path)[0] + ".jpg"
    try:
        fig.savefig(jpg_path, dpi=EXPORT_DPI, facecolor="white", bbox_inches="tight", format="jpg", pil_kwargs={"quality": 92})
        print(f"[trappist1_presentation] Wrote {jpg_path}")
    except Exception:
        pass

    plt.close(fig)
    print(f"[trappist1_presentation] Wrote {out_path}")
    return out_path


def _merged_rows_trappist() -> List[Tuple[str, Dict[str, Any]]]:
    """NASA-style merged rows for build_features (one per planet)."""
    from src.physics.system_presets import get_trappist1_system

    specs = get_trappist1_system()
    star_spec = next(s for s in specs if s.get("type") == "star")
    st_teff = float(star_spec.get("temperature", 2550.0))
    st_mass = float(star_spec.get("mass", 0.089))
    st_rad = float(star_spec.get("radius", 0.121))
    st_lum = float(star_spec.get("luminosity", 5.5e-4))

    rows: List[Tuple[str, Dict[str, Any]]] = []
    for s in specs:
        if s.get("type") != "planet":
            continue
        name = s.get("name", "")
        row = {
            "pl_rade": float(s.get("radius", 1.0)),
            "pl_masse": float(s.get("mass", 1.0)),
            "pl_orbper": float(s.get("orbital_period", 10.0)),
            "pl_orbsmax": float(s.get("semi_major_axis", 0.05)),
            "pl_orbeccen": float(s.get("eccentricity", 0.01)),
            "pl_insol": float(s.get("stellarFlux", 1.0)),
            "pl_eqt": float(s.get("equilibrium_temperature", 250.0)),
            "st_teff": st_teff,
            "st_mass": st_mass,
            "st_rad": st_rad,
            "st_lum": st_lum,
        }
        rows.append((name, row))
    return rows


def export_shap_waterfalls(out_dir: Optional[str] = None) -> List[str]:
    """
    One SHAP waterfall PNG per TRAPPIST-1 planet using the loaded XGBoost habitability model.
    """
    try:
        import matplotlib

        matplotlib.use("Agg")
        import matplotlib.patches as mpatches
        import matplotlib.pyplot as plt
        import shap
    except ImportError as e:
        print("[trappist1_presentation] SHAP export skipped (need shap, xgboost, matplotlib):", e)
        return []

    from src.ml.ml_features import build_features, load_feature_schema
    from src.ml.ml_habitability import MLHabitabilityCalculator
    from src.utils.paths import feature_schema_path

    _set_publication_style()
    schema = load_feature_schema(feature_schema_path())
    feature_names = [f["name"] for f in schema["features"]]
    display_names = _display_feature_names(feature_names)
    idx_by_name = {n: j for j, n in enumerate(feature_names)}

    calc = MLHabitabilityCalculator()
    earth_raw = float(getattr(calc, "earth_raw_score", 0.9424))
    rows = _merged_rows_trappist()
    if not rows:
        return []

    X_list: List[np.ndarray] = []
    labels: List[str] = []
    for name, row in rows:
        vec, _ = build_features(row, return_meta=True)
        X_list.append(vec)
        labels.append(name)

    X = np.vstack(X_list).astype(np.float64)

    explainer = shap.TreeExplainer(calc.model)
    sv = explainer.shap_values(X)
    base = float(explainer.expected_value) if np.isscalar(explainer.expected_value) else float(explainer.expected_value[0])

    if out_dir is None:
        out_dir = os.path.join(_exports_dir(), "shap")
    os.makedirs(out_dir, exist_ok=True)

    # Focus this presentation export on TRAPPIST-1e.
    try:
        target_i = labels.index("TRAPPIST-1 e")
    except ValueError:
        return []

    raw_pred = float(base + np.sum(sv[target_i]))
    raw_pred = float(np.clip(raw_pred, 0.0, 1.0))
    earth_pct = float((raw_pred / earth_raw) * 100.0) if earth_raw > 0 else raw_pred * 100.0
    earth_pct = float(np.clip(earth_pct, 0.0, 100.0))

    shap_row = np.asarray(sv[target_i], dtype=float)
    x_row = np.asarray(X[target_i], dtype=float)
    records: List[Tuple[str, str, float]] = []
    for j, raw_name in enumerate(feature_names):
        display = display_names[j]
        value = _format_feature_value(raw_name, float(x_row[j]))
        dual_label = f"{display.split(' (')[0]} ({value})"
        records.append((raw_name, dual_label, float(shap_row[j])))

    records_sorted = sorted(records, key=lambda r: abs(r[2]), reverse=True)
    top_n = 6
    top_records = records_sorted[:top_n]
    rest_records = records_sorted[top_n:]
    baseline_sum = float(sum(r[2] for r in rest_records))

    y_labels = [r[1] for r in top_records] + ["Baseline Physical Constraints"]
    values = [r[2] for r in top_records] + [baseline_sum]

    # Presentation style requested: dark space-black + modern sans font stack.
    plt.rcParams.update(
        {
            "font.family": "sans-serif",
            "font.sans-serif": ["IBM Plex Sans", "Inter", "DejaVu Sans", "Arial"],
        }
    )
    fig, ax = plt.subplots(figsize=(13, 8), facecolor="#0f172a")
    ax.set_facecolor("#0f172a")

    y_positions = np.arange(len(y_labels), dtype=float)
    height = 0.72
    colors = ["#27ae60" if v >= 0 else "#2980b9" for v in values]

    for y, w, c in zip(y_positions, values, colors):
        x0 = min(0.0, w)
        ww = abs(w)
        patch = mpatches.FancyBboxPatch(
            (x0, y - height / 2.0),
            ww,
            height,
            boxstyle="round,pad=0.0,rounding_size=0.02",
            linewidth=0.0,
            facecolor=c,
            edgecolor=c,
        )
        ax.add_patch(patch)

    x_max = max(1e-6, float(np.max(np.abs(values))) * 1.25)
    ax.set_xlim(-x_max, x_max)
    ax.set_ylim(-0.8, len(y_labels) - 0.2)
    ax.invert_yaxis()
    ax.axvline(0.0, color="#94a3b8", linewidth=1.0, alpha=0.6)
    ax.grid(axis="x", color="#334155", linestyle="-", linewidth=0.6, alpha=0.45)
    for spine in ax.spines.values():
        spine.set_visible(False)

    ax.set_yticks(y_positions)
    ax.set_yticklabels(y_labels, color="#e2e8f0", fontsize=11)
    ax.tick_params(axis="x", colors="#cbd5e1", labelsize=10)
    ax.set_xlabel("SHAP contribution to AIET raw score (model-output space)", color="#cbd5e1", fontsize=11, labelpad=8)

    for y, w in zip(y_positions, values):
        ha = "left" if w >= 0 else "right"
        dx = 0.01 * x_max if w >= 0 else -0.01 * x_max
        ax.text(w + dx, y, f"{w:+.3f}", va="center", ha=ha, color="#e2e8f0", fontsize=10, fontweight="medium")

    fig.text(
        0.055,
        0.95,
        "AIET v3.1 SHAP Attribution Chart - TRAPPIST-1e",
        color="#f8fafc",
        fontsize=16,
        fontweight="bold",
        ha="left",
        va="top",
    )
    fig.text(
        0.055,
        0.91,
        "Ranked by absolute impact (Top 6 + aggregated baseline constraints)",
        color="#94a3b8",
        fontsize=10.5,
        ha="left",
        va="top",
    )

    # "Wow" header box with subtle glow layering.
    for pad, alpha in [(0.9, 0.18), (0.55, 0.26), (0.35, 0.92)]:
        fig.text(
            0.975,
            0.955,
            "95.6% Earth-Similarity" if alpha > 0.9 else "",
            ha="right",
            va="top",
            fontsize=18,
            fontweight="bold",
            color="#dcfce7",
            bbox=dict(boxstyle=f"round,pad={pad}", fc="#14532d", ec="#27ae60", alpha=alpha),
        )
    fig.text(
        0.975,
        0.902,
        "AIET v3.1 | N-body verified: \u0394E/E\u2080 < 10\u207b\u2076",
        ha="right",
        va="top",
        fontsize=8.8,
        color="#bfdbfe",
    )

    fig.text(
        0.055,
        0.03,
        "Life-Green = positive habitability drivers | Deep Atmospheric Blue = negative drivers",
        color="#94a3b8",
        fontsize=9,
        ha="left",
    )

    plt.tight_layout(rect=[0.04, 0.07, 0.98, 0.89])
    p = os.path.join(out_dir, "trappist1e_shap_ranked_bar.png")
    fig.savefig(p, dpi=EXPORT_DPI, bbox_inches="tight", facecolor="#0f172a")
    plt.close(fig)
    print(f"[trappist1_presentation] Wrote {p}")
    return [p]


def main() -> None:
    # 100 yr / 0.02 yr outer step * 20 substeps = 1e5 leapfrog substeps (good for captions)
    export_energy_plot(
        duration_years=100.0,
        dt_years=0.02,
        n_substeps=20,
        record_every_outer_steps=25,
    )
    export_shap_waterfalls()
    print(f"[trappist1_presentation] Done. Outputs under {_exports_dir()}")


if __name__ == "__main__":
    main()
