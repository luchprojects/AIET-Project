"""
AIET Benchmark & Calibration Suite

Formal validation framework for scientific plausibility, regression protection,
and research credibility. This module provides reproducible, automated tests
that verify expected behaviors without modifying core ML or integrator logic.

Benchmark Categories:
    1. SOLAR SYSTEM RANKING: Verifies qualitative habitability ordering
    2. EARTH NORMALIZATION: Verifies Earth scores exactly 100.0
    3. ORBITAL STABILITY: Verifies integrator energy conservation
    4. MONTE CARLO SCALING: Verifies statistical properties of MC sampling

Expected Qualitative Behaviors:
    - Earth should score highest among terrestrial planets
    - Gas giants should score near zero (uninhabitable)
    - Venus/Mars should score lower than Earth but non-zero
    - Mercury should score very low (extreme temperatures)
    - Standard error should decrease as ~1/sqrt(N)
    - Energy drift should remain bounded for symplectic integrators

Tolerances Used:
    - Earth normalization: |score - 100| < 1e-6
    - Energy conservation (Verlet): |ΔE/E₀| < 1e-6
    - Semi-major axis variation: < 1% over 10 years
    - MC scaling: SE ratio within 20% of theoretical 1/sqrt(N)

Limitations:
    - NOT empirical validation against life detection
    - Does not verify absolute habitability correctness
    - Only tests internal consistency and expected orderings
    - Tolerances are heuristics based on numerical precision

Usage:
    from benchmark_suite import run_all_benchmarks, export_benchmark_report_json
    
    results = run_all_benchmarks()
    if results["all_passed"]:
        print("All benchmarks passed!")
    export_benchmark_report_json(results, "exports/benchmark_report.json")
"""

from __future__ import annotations

import json
import os
import time
from dataclasses import dataclass, field, asdict
from datetime import datetime
from typing import Dict, List, Optional, Any, Tuple

import numpy as np


# =============================================================================
# CANONICAL SOLAR SYSTEM DATA (NASA values)
# =============================================================================

SOLAR_SYSTEM_PLANETS: Dict[str, Dict[str, float]] = {
    "Mercury": {
        "pl_rade": 0.383,      # Earth radii
        "pl_masse": 0.055,     # Earth masses
        "pl_orbper": 87.97,    # days
        "pl_orbsmax": 0.387,   # AU
        "pl_orbeccen": 0.206,
        "pl_insol": 6.67,      # Earth insolation
        "pl_eqt": 440.0,       # K (mean)
        "pl_dens": 5.43,       # g/cm³
        "st_teff": 5778.0,
        "st_mass": 1.0,
        "st_rad": 1.0,
        "st_lum": 1.0,
    },
    "Venus": {
        "pl_rade": 0.949,
        "pl_masse": 0.815,
        "pl_orbper": 224.7,
        "pl_orbsmax": 0.723,
        "pl_orbeccen": 0.007,
        "pl_insol": 1.91,
        "pl_eqt": 737.0,       # Surface temp (greenhouse)
        "pl_dens": 5.24,
        "st_teff": 5778.0,
        "st_mass": 1.0,
        "st_rad": 1.0,
        "st_lum": 1.0,
    },
    "Earth": {
        "pl_rade": 1.0,
        "pl_masse": 1.0,
        "pl_orbper": 365.25,
        "pl_orbsmax": 1.0,
        "pl_orbeccen": 0.0167,
        "pl_insol": 1.0,
        "pl_eqt": 255.0,       # Equilibrium temp
        "pl_dens": 5.51,
        "st_teff": 5778.0,
        "st_mass": 1.0,
        "st_rad": 1.0,
        "st_lum": 1.0,
    },
    "Mars": {
        "pl_rade": 0.532,
        "pl_masse": 0.107,
        "pl_orbper": 687.0,
        "pl_orbsmax": 1.524,
        "pl_orbeccen": 0.093,
        "pl_insol": 0.43,
        "pl_eqt": 210.0,
        "pl_dens": 3.93,
        "st_teff": 5778.0,
        "st_mass": 1.0,
        "st_rad": 1.0,
        "st_lum": 1.0,
    },
    "Jupiter": {
        "pl_rade": 11.21,
        "pl_masse": 317.8,
        "pl_orbper": 4333.0,
        "pl_orbsmax": 5.203,
        "pl_orbeccen": 0.049,
        "pl_insol": 0.037,
        "pl_eqt": 110.0,
        "pl_dens": 1.33,
        "st_teff": 5778.0,
        "st_mass": 1.0,
        "st_rad": 1.0,
        "st_lum": 1.0,
    },
}


# =============================================================================
# BENCHMARK RESULT DATACLASSES
# =============================================================================

@dataclass
class BenchmarkResult:
    """Result of a single benchmark test."""
    name: str
    passed: bool
    message: str
    details: Dict[str, Any] = field(default_factory=dict)
    duration_ms: float = 0.0
    
    def __str__(self) -> str:
        status = "PASS" if self.passed else "FAIL"
        return f"[{status}] {self.name}: {self.message}"


@dataclass
class BenchmarkSuiteResults:
    """Aggregate results from all benchmarks."""
    all_passed: bool
    total_tests: int
    passed_tests: int
    failed_tests: int
    results: List[BenchmarkResult]
    timestamp: str = ""
    total_duration_ms: float = 0.0
    
    def __post_init__(self):
        if not self.timestamp:
            self.timestamp = datetime.now().isoformat()
    
    def summary(self) -> str:
        lines = [
            "AIET Benchmark Suite Results",
            "=" * 60,
            f"Timestamp: {self.timestamp}",
            f"Total Duration: {self.total_duration_ms:.1f} ms",
            "",
            f"Results: {self.passed_tests}/{self.total_tests} passed",
            "",
        ]
        
        for result in self.results:
            status = "✓" if result.passed else "✗"
            lines.append(f"  {status} {result.name}")
            lines.append(f"      {result.message}")
        
        lines.append("")
        lines.append(f"Overall: {'ALL PASSED' if self.all_passed else 'SOME FAILED'}")
        
        return "\n".join(lines)


# =============================================================================
# BENCHMARK TESTS
# =============================================================================

def benchmark_solar_system_ranking(calculator: Any) -> BenchmarkResult:
    """
    Test 1: Solar System Habitability Ranking
    
    Verifies qualitative ordering:
    - Earth highest among terrestrial planets
    - Gas giants score near zero
    - Mars/Venus lower than Earth but > 0
    """
    start = time.time()
    
    scores = {}
    for planet_name, planet_data in SOLAR_SYSTEM_PLANETS.items():
        try:
            score = calculator.predict(planet_data, return_raw=False)
            scores[planet_name] = float(score)
        except Exception as e:
            return BenchmarkResult(
                name="Solar System Ranking",
                passed=False,
                message=f"Prediction failed for {planet_name}: {e}",
                duration_ms=(time.time() - start) * 1000,
            )
    
    errors = []
    
    terrestrial = ["Mercury", "Venus", "Earth", "Mars"]
    terrestrial_scores = {p: scores[p] for p in terrestrial}
    earth_score = scores["Earth"]
    
    for planet in ["Mercury", "Venus", "Mars"]:
        if scores[planet] >= earth_score:
            errors.append(f"{planet} ({scores[planet]:.2f}) >= Earth ({earth_score:.2f})")
    
    jupiter_score = scores["Jupiter"]
    gas_giant_threshold = 10.0
    if jupiter_score > gas_giant_threshold:
        errors.append(f"Jupiter ({jupiter_score:.2f}) > {gas_giant_threshold} (gas giant threshold)")
    
    if scores["Mars"] <= 0 or scores["Venus"] <= 0:
        errors.append(f"Mars ({scores['Mars']:.2f}) or Venus ({scores['Venus']:.2f}) scored ≤ 0")
    
    passed = len(errors) == 0
    
    if passed:
        message = f"Ranking correct: Earth ({earth_score:.1f}) > Mars ({scores['Mars']:.1f}) > Venus ({scores['Venus']:.1f})"
    else:
        message = f"Ranking errors: {'; '.join(errors)}"
    
    return BenchmarkResult(
        name="Solar System Ranking",
        passed=passed,
        message=message,
        details={"scores": scores, "errors": errors},
        duration_ms=(time.time() - start) * 1000,
    )


def benchmark_earth_normalization(calculator: Any) -> BenchmarkResult:
    """
    Test 2: Earth Normalization
    
    Verifies Earth scores exactly 100.0 (within floating point tolerance).
    """
    start = time.time()
    
    earth_data = SOLAR_SYSTEM_PLANETS["Earth"]
    
    try:
        score = calculator.predict(earth_data, return_raw=False)
    except Exception as e:
        return BenchmarkResult(
            name="Earth Normalization",
            passed=False,
            message=f"Prediction failed: {e}",
            duration_ms=(time.time() - start) * 1000,
        )
    
    tolerance = 1e-6
    deviation = abs(score - 100.0)
    passed = deviation < tolerance
    
    if passed:
        message = f"Earth score = {score:.10f} (deviation: {deviation:.2e})"
    else:
        message = f"Earth score = {score:.6f}, expected 100.0 (deviation: {deviation:.6f} > {tolerance})"
    
    return BenchmarkResult(
        name="Earth Normalization",
        passed=passed,
        message=message,
        details={"score": score, "deviation": deviation, "tolerance": tolerance},
        duration_ms=(time.time() - start) * 1000,
    )


def benchmark_two_body_orbital_stability(
    duration: float = 10.0,
    dt: float = 0.001,
    energy_tolerance: float = 1e-6,
    sma_tolerance: float = 0.01,
) -> BenchmarkResult:
    """
    Test 3: Two-Body Orbital Stability
    
    Runs Sun-Earth simulation for specified duration and verifies:
    - Energy conservation (max drift < tolerance)
    - Semi-major axis stability (variation < tolerance)
    """
    start = time.time()
    
    try:
        from src.physics.integrator_diagnostics import run_integrator_validation, IntegratorDiagnostics
    except ImportError as e:
        return BenchmarkResult(
            name="Two-Body Orbital Stability",
            passed=False,
            message=f"integrator_diagnostics not available: {e}",
            duration_ms=(time.time() - start) * 1000,
        )
    
    G = 39.478
    earth_orbital_velocity = np.sqrt(G * 1.0 / 1.0)
    
    bodies = [
        {
            "name": "Sun",
            "type": "star",
            "mass": 1.0,
            "position": np.array([0.0, 0.0]),
            "velocity": np.array([0.0, 0.0]),
        },
        {
            "name": "Earth",
            "type": "planet",
            "mass": 1.0,
            "position": np.array([1.0, 0.0]),
            "velocity": np.array([0.0, earth_orbital_velocity]),
        },
    ]
    
    try:
        metrics = run_integrator_validation(
            bodies=bodies,
            duration=duration,
            dt=dt,
            integrator="verlet",
            record_interval=100,
        )
    except Exception as e:
        return BenchmarkResult(
            name="Two-Body Orbital Stability",
            passed=False,
            message=f"Integration failed: {e}",
            duration_ms=(time.time() - start) * 1000,
        )
    
    errors = []
    
    if metrics.max_energy_drift > energy_tolerance:
        errors.append(f"Energy drift {metrics.max_energy_drift:.2e} > {energy_tolerance:.2e}")
    
    passed = len(errors) == 0
    
    if passed:
        message = (f"Stable over {duration} years: "
                   f"|ΔE/E₀| = {metrics.max_energy_drift:.2e}, "
                   f"|ΔL/L₀| = {metrics.max_angular_momentum_drift:.2e}")
    else:
        message = f"Stability issues: {'; '.join(errors)}"
    
    return BenchmarkResult(
        name="Two-Body Orbital Stability",
        passed=passed,
        message=message,
        details={
            "duration": duration,
            "dt": dt,
            "max_energy_drift": metrics.max_energy_drift,
            "final_energy_drift": metrics.final_energy_drift,
            "max_angular_momentum_drift": metrics.max_angular_momentum_drift,
            "energy_tolerance": energy_tolerance,
            "sma_tolerance": sma_tolerance,
        },
        duration_ms=(time.time() - start) * 1000,
    )


def benchmark_monte_carlo_scaling(
    calculator: Any,
    sample_counts: List[int] = None,
    scaling_tolerance: float = 0.20,
) -> BenchmarkResult:
    """
    Test 4: Monte Carlo Scaling
    
    Verifies:
    - Standard error decreases as ~1/sqrt(N)
    - Increasing fallback uncertainty increases std_dev
    """
    start = time.time()
    
    if sample_counts is None:
        sample_counts = [500, 1000, 2000]
    
    earth_data = SOLAR_SYSTEM_PLANETS["Earth"].copy()
    
    results_by_n = {}
    for N in sample_counts:
        try:
            result = calculator.predict_with_uncertainty(
                planet_data=earth_data,
                N=N,
                seed=42,
            )
            results_by_n[N] = {
                "mean": result.get("mean_index", 0),
                "std_dev": result.get("std_dev", 0),
                "standard_error": result.get("standard_error", 0),
            }
        except Exception as e:
            return BenchmarkResult(
                name="Monte Carlo Scaling",
                passed=False,
                message=f"MC failed for N={N}: {e}",
                duration_ms=(time.time() - start) * 1000,
            )
    
    errors = []
    
    n_values = sorted(results_by_n.keys())
    if len(n_values) >= 2:
        for i in range(len(n_values) - 1):
            n1, n2 = n_values[i], n_values[i + 1]
            se1, se2 = results_by_n[n1]["standard_error"], results_by_n[n2]["standard_error"]
            
            if se1 > 0 and se2 > 0:
                actual_ratio = se1 / se2
                expected_ratio = np.sqrt(n2 / n1)
                relative_error = abs(actual_ratio - expected_ratio) / expected_ratio
                
                if relative_error > scaling_tolerance:
                    errors.append(
                        f"SE scaling N={n1}→{n2}: actual ratio {actual_ratio:.3f}, "
                        f"expected {expected_ratio:.3f} (error: {relative_error:.1%})"
                    )
    
    try:
        from src.ml.ml_uncertainty import DEFAULT_FALLBACK_UNCERTAINTY
        large_fallback = {
            k: v * 3 if not isinstance(v, tuple) else v 
            for k, v in DEFAULT_FALLBACK_UNCERTAINTY.items()
        }
        
        result_normal = calculator.predict_with_uncertainty(
            planet_data=earth_data, N=500, seed=123
        )
        result_large = calculator.predict_with_uncertainty(
            planet_data=earth_data, N=500, seed=123, fallback_config=large_fallback
        )
        
        if result_large["std_dev"] <= result_normal["std_dev"]:
            errors.append(
                f"Larger fallback did not increase std_dev: "
                f"normal={result_normal['std_dev']:.3f}, large={result_large['std_dev']:.3f}"
            )
    except ImportError:
        pass
    
    passed = len(errors) == 0
    
    if passed:
        se_values = [results_by_n[n]["standard_error"] for n in n_values]
        message = f"SE scaling correct: {' → '.join([f'N={n}:SE={se:.4f}' for n, se in zip(n_values, se_values)])}"
    else:
        message = f"Scaling issues: {'; '.join(errors)}"
    
    return BenchmarkResult(
        name="Monte Carlo Scaling",
        passed=passed,
        message=message,
        details={
            "results_by_n": results_by_n,
            "scaling_tolerance": scaling_tolerance,
            "errors": errors,
        },
        duration_ms=(time.time() - start) * 1000,
    )


def benchmark_deterministic_consistency(
    calculator: Any,
    n_runs: int = 5,
) -> BenchmarkResult:
    """
    Test 5: Deterministic Consistency
    
    Verifies that predict() returns identical results across multiple calls.
    """
    start = time.time()
    
    earth_data = SOLAR_SYSTEM_PLANETS["Earth"]
    
    scores = []
    for i in range(n_runs):
        try:
            score = calculator.predict(earth_data, return_raw=False)
            scores.append(float(score))
        except Exception as e:
            return BenchmarkResult(
                name="Deterministic Consistency",
                passed=False,
                message=f"Prediction failed on run {i+1}: {e}",
                duration_ms=(time.time() - start) * 1000,
            )
    
    unique_scores = set(scores)
    passed = len(unique_scores) == 1
    
    if passed:
        message = f"Consistent: {n_runs} runs all returned {scores[0]:.10f}"
    else:
        message = f"Inconsistent: got {len(unique_scores)} different values: {unique_scores}"
    
    return BenchmarkResult(
        name="Deterministic Consistency",
        passed=passed,
        message=message,
        details={"scores": scores, "n_runs": n_runs},
        duration_ms=(time.time() - start) * 1000,
    )


def benchmark_edge_cases(calculator: Any) -> BenchmarkResult:
    """
    Test 6: Edge Cases
    
    Verifies model handles edge cases gracefully:
    - Extreme values should not crash
    - Scores should remain in [0, 100] range
    """
    start = time.time()
    
    edge_cases = {
        "hot_jupiter": {
            "pl_rade": 15.0, "pl_masse": 400.0, "pl_orbper": 3.0,
            "pl_orbsmax": 0.05, "pl_orbeccen": 0.1, "pl_insol": 50.0,
            "pl_eqt": 1500.0, "pl_dens": 1.0,
            "st_teff": 6000.0, "st_mass": 1.2, "st_rad": 1.3, "st_lum": 2.0,
        },
        "cold_super_earth": {
            "pl_rade": 2.0, "pl_masse": 5.0, "pl_orbper": 1000.0,
            "pl_orbsmax": 3.0, "pl_orbeccen": 0.3, "pl_insol": 0.1,
            "pl_eqt": 150.0, "pl_dens": 6.0,
            "st_teff": 4000.0, "st_mass": 0.7, "st_rad": 0.7, "st_lum": 0.2,
        },
        "tidally_locked": {
            "pl_rade": 1.1, "pl_masse": 1.2, "pl_orbper": 10.0,
            "pl_orbsmax": 0.1, "pl_orbeccen": 0.0, "pl_insol": 5.0,
            "pl_eqt": 400.0, "pl_dens": 5.5,
            "st_teff": 3500.0, "st_mass": 0.3, "st_rad": 0.3, "st_lum": 0.01,
        },
    }
    
    errors = []
    scores = {}
    
    for case_name, case_data in edge_cases.items():
        try:
            score = calculator.predict(case_data, return_raw=False)
            scores[case_name] = float(score)
            
            if score < 0 or score > 100:
                errors.append(f"{case_name}: score {score} out of [0,100] range")
                
        except Exception as e:
            errors.append(f"{case_name}: crashed with {type(e).__name__}: {e}")
    
    passed = len(errors) == 0
    
    if passed:
        message = f"All edge cases handled: {', '.join([f'{k}={v:.1f}' for k, v in scores.items()])}"
    else:
        message = f"Edge case issues: {'; '.join(errors)}"
    
    return BenchmarkResult(
        name="Edge Cases",
        passed=passed,
        message=message,
        details={"scores": scores, "errors": errors},
        duration_ms=(time.time() - start) * 1000,
    )


# =============================================================================
# AGGREGATE RUNNER
# =============================================================================

def run_all_benchmarks(
    calculator: Any = None,
    skip_integrator: bool = False,
    verbose: bool = True,
) -> BenchmarkSuiteResults:
    """
    Run all benchmarks and return aggregate results.
    
    Args:
        calculator: MLHabitabilityCalculatorV4 instance. If None, will create one.
        skip_integrator: If True, skip orbital stability test.
        verbose: If True, print progress.
        
    Returns:
        BenchmarkSuiteResults with all test results.
    """
    start_total = time.time()
    
    if calculator is None:
        try:
            from src.ml.ml_habitability import MLHabitabilityCalculator
            calculator = MLHabitabilityCalculatorV4()
        except ImportError as e:
            return BenchmarkSuiteResults(
                all_passed=False,
                total_tests=0,
                passed_tests=0,
                failed_tests=0,
                results=[BenchmarkResult(
                    name="Setup",
                    passed=False,
                    message=f"Could not import ML calculator: {e}",
                )],
            )
    
    results = []
    
    if verbose:
        print("Running AIET Benchmark Suite...")
        print("-" * 50)
    
    if verbose:
        print("  [1/6] Solar System Ranking...")
    results.append(benchmark_solar_system_ranking(calculator))
    
    if verbose:
        print("  [2/6] Earth Normalization...")
    results.append(benchmark_earth_normalization(calculator))
    
    if not skip_integrator:
        if verbose:
            print("  [3/6] Two-Body Orbital Stability...")
        results.append(benchmark_two_body_orbital_stability())
    
    if verbose:
        print("  [4/6] Monte Carlo Scaling...")
    results.append(benchmark_monte_carlo_scaling(calculator))
    
    if verbose:
        print("  [5/6] Deterministic Consistency...")
    results.append(benchmark_deterministic_consistency(calculator))
    
    if verbose:
        print("  [6/6] Edge Cases...")
    results.append(benchmark_edge_cases(calculator))
    
    total_duration = (time.time() - start_total) * 1000
    
    passed = sum(1 for r in results if r.passed)
    failed = len(results) - passed
    
    suite_results = BenchmarkSuiteResults(
        all_passed=(failed == 0),
        total_tests=len(results),
        passed_tests=passed,
        failed_tests=failed,
        results=results,
        total_duration_ms=total_duration,
    )
    
    if verbose:
        print("-" * 50)
        print(suite_results.summary())
    
    return suite_results


# =============================================================================
# EXPORT FUNCTIONS
# =============================================================================

def export_benchmark_report_json(
    results: BenchmarkSuiteResults,
    output_path: str,
    indent: int = 2,
) -> str:
    """
    Export benchmark results to JSON file.
    
    Args:
        results: BenchmarkSuiteResults instance.
        output_path: Path to save JSON file.
        indent: JSON indentation.
        
    Returns:
        Path to saved file.
    """
    os.makedirs(os.path.dirname(output_path) or ".", exist_ok=True)
    
    report_dict = {
        "all_passed": results.all_passed,
        "total_tests": results.total_tests,
        "passed_tests": results.passed_tests,
        "failed_tests": results.failed_tests,
        "timestamp": results.timestamp,
        "total_duration_ms": results.total_duration_ms,
        "results": [asdict(r) for r in results.results],
    }
    
    with open(output_path, 'w') as f:
        json.dump(report_dict, f, indent=indent, default=str)
    
    print(f"[Benchmark] Exported report to: {output_path}")
    return output_path


def export_benchmark_report_summary(
    results: BenchmarkSuiteResults,
    output_path: str,
) -> str:
    """
    Export human-readable benchmark summary to text file.
    
    Args:
        results: BenchmarkSuiteResults instance.
        output_path: Path to save text file.
        
    Returns:
        Path to saved file.
    """
    os.makedirs(os.path.dirname(output_path) or ".", exist_ok=True)
    
    with open(output_path, 'w') as f:
        f.write(results.summary())
    
    print(f"[Benchmark] Exported summary to: {output_path}")
    return output_path


# =============================================================================
# VALIDATION (run with: python -m benchmark_suite)
# =============================================================================

if __name__ == "__main__":
    import sys
    
    print("=" * 70)
    print("AIET Benchmark & Calibration Suite")
    print("=" * 70)
    print()
    
    try:
        from src.ml.ml_habitability import MLHabitabilityCalculator
        calc = MLHabitabilityCalculatorV4()
    except ImportError as e:
        print(f"Could not import ML calculator: {e}")
        sys.exit(1)
    
    results = run_all_benchmarks(calculator=calc, verbose=True)
    
    os.makedirs("exports", exist_ok=True)
    json_path = export_benchmark_report_json(results, "exports/benchmark_report.json")
    txt_path = export_benchmark_report_summary(results, "exports/benchmark_report.txt")
    
    print()
    print("=" * 70)
    print("Benchmark Documentation:")
    print("-" * 70)
    print("Solar System Ranking: Verifies Earth > Mars > Venus among terrestrials")
    print("Earth Normalization: Verifies Earth scores exactly 100.0")
    print("Orbital Stability: Verifies Verlet integrator conserves energy")
    print("MC Scaling: Verifies SE decreases as 1/sqrt(N)")
    print("Deterministic: Verifies predict() gives same result each call")
    print("Edge Cases: Verifies model handles extreme inputs gracefully")
    print("-" * 70)
    print("Tolerances:")
    print("  Earth normalization: |score - 100| < 1e-6")
    print("  Energy conservation: |ΔE/E₀| < 1e-6")
    print("  MC scaling: SE ratio within 20% of theoretical")
    print("-" * 70)
    print("Limitations:")
    print("  - NOT empirical validation against life detection")
    print("  - Only tests internal consistency and expected orderings")
    print("  - Tolerances are heuristics based on numerical precision")
    print("=" * 70)
    
    sys.exit(0 if results.all_passed else 1)
