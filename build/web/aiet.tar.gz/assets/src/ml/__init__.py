# ML pipeline: habitability, features, integration, uncertainty, surface classification
