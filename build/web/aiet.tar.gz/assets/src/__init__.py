# AIET source package. Run from project root: python -m src.main
