"""
AIET path resolution for PyInstaller and development.
Single source of truth for fonts, ml_calibration, and other assets.
"""
from __future__ import annotations

import os
import sys
from typing import Optional

# Base: when frozen (PyInstaller), sys._MEIPASS; else directory containing this file
def _base_dir() -> str:
    if getattr(sys, "frozen", False):
        return sys._MEIPASS
    return os.path.dirname(os.path.abspath(__file__))


def project_root() -> str:
    """AIET project root (parent of src/)."""
    base = _base_dir()
    if os.path.basename(base) == "utils":
        base = os.path.dirname(os.path.dirname(base))
    elif os.path.basename(base) == "src":
        base = os.path.dirname(base)
    return base


def ml_calibration_dir() -> str:
    """Directory containing hab_xgb.json and features.json. Runtime only."""
    return os.path.join(project_root(), "ml_calibration")


def model_path(filename: str = "hab_xgb.json") -> str:
    """Absolute path to a file in ml_calibration/."""
    return os.path.join(ml_calibration_dir(), filename)


def feature_schema_path() -> str:
    """Absolute path to features.json."""
    return model_path("features.json")


def fonts_dir() -> str:
    """Directory containing Inter-Regular.ttf, Inter-Bold.ttf (UI assets)."""
    return os.path.join(project_root(), "src", "ui", "fonts")


def font_path(name: str = "Inter-Regular.ttf") -> str:
    """Absolute path to a font file in fonts/."""
    return os.path.join(fonts_dir(), name)
