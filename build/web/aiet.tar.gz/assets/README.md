# AIET — Artificial Intelligence for Extraterrestrial

AIET is a physics-informed machine learning and visualization platform for exploratory analysis of exoplanet habitability using data from the NASA Exoplanet Archive.

## Project Purpose

AIET is designed for exploration, comparison, and education rather than definitive life detection.  
The goal is to provide an interactive way to understand how stellar, orbital, and planetary parameters influence relative habitability outcomes.

## Key Features

- Physics-informed feature engineering (density, insolation, escape velocity, tidal locking)
- Machine learning–based relative habitability scoring
- Interactive visualization for comparative planetary analysis
- Modular Python pipeline for data processing and experimentation

## Data Sources

- NASA Exoplanet Archive  
  https://exoplanetarchive.ipac.caltech.edu/

All derived quantities are computed from publicly available archival data.

## Repository Structure

```
AIET/
├── src/                 # Application and library code
│   ├── physics/         # Simulation and integrator
│   ├── ml/              # ML pipeline (habitability, features, integration, teacher, validation, sanity check)
│   ├── ui/              # Main window, diagnostics, camera, renderer
│   ├── science/         # Benchmarks, model integrity, sensitivity analysis
│   ├── utils/           # Paths and shared utilities
│   └── main.py          # Entry point
├── ml_calibration/      # Model artifacts (hab_xgb.json, features.json)
├── ml_training/         # Training data and script (exoplanets.csv, stellar_hosts.csv, train_ml_xgb.py)
├── docs/                # Documentation (ML guides, summaries)
├── tests/               # Test suite (integration, sanity check, orbit, surface classification)
├── exports/             # Generated outputs
├── fonts/               # UI fonts
└── README.md
```

## Installation

```bash
git clone https://github.com/yourusername/AIET.git
cd AIET
pip install -r requirements.txt
```

Run the desktop app:

```bash
python src/main.py
```

### Browser build (WASM, pygbag)

To package the same Pygame app for the web (shareable link), see **`docs/WEB_DEPLOY.md`**. Quick local test:

```bash
pip install -r requirements-web.txt
python -m pygbag --build --app_name aiet .
```

Output is in **`build/web/`**. GitHub Actions can publish that folder to Pages (workflow **Deploy web (pygbag)**).

---
## Project Status

This project is under active development.  
The current version represents an early working prototype focused on pipeline design, interpretability, and visualization.  
Model refinement, validation, and UI improvements are ongoing.

## Disclaimer

AIET is a research and educational project.  
Habitability scores are normalized and intended for relative comparison only.

## Planned Work

- Model validation against known planetary regimes
- Improved UI labeling and visualization clarity
- Expanded interactive parameter exploration
- Educational use cases and outreach integration